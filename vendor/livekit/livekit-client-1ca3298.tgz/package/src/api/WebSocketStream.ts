// https://github.com/CarterLi/websocketstream-polyfill
import { ConnectionError } from '../room/errors';
import { sleep } from '../room/utils';
import TypedPromise from '../utils/TypedPromise';
import { getErrorDescription } from './utils';

export interface WebSocketConnection<T extends ArrayBuffer | string = ArrayBuffer | string> {
  readable: ReadableStream<T>;
  writable: WritableStream<T>;
  protocol: string;
  extensions: string;
}

export interface WebSocketCloseInfo {
  closeCode?: number;
  reason?: string;
}

export interface WebSocketStreamOptions {
  protocols?: string[];
  signal?: AbortSignal;
}

type WebsocketError = ReturnType<typeof ConnectionError.websocket>;

/**
 * [WebSocket](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket) with [Streams API](https://developer.mozilla.org/en-US/docs/Web/API/Streams_API)
 *
 * @see https://web.dev/websocketstream/
 */
export class WebSocketStream<T extends ArrayBuffer | string = ArrayBuffer | string> {
  readonly url: string;

  readonly opened: TypedPromise<WebSocketConnection<T>, WebsocketError>;

  readonly closed: TypedPromise<WebSocketCloseInfo, WebsocketError>;

  readonly close: (closeInfo?: WebSocketCloseInfo) => void;

  get readyState(): number {
    return this.ws.readyState;
  }

  private ws: WebSocket;

  constructor(url: string, options: WebSocketStreamOptions = {}) {
    if (options.signal?.aborted) {
      throw new DOMException('This operation was aborted', 'AbortError');
    }

    this.url = url;

    const ws = new WebSocket(url, options.protocols ?? []);
    ws.binaryType = 'arraybuffer';
    this.ws = ws;

    // React Native has non spec-compliant behavior on close() before open:
    // iOS sends only `close`, and only once the TCP connect settles.
    // Android ignores the close and will open the socket anyway.
    // To fix this, close() before open rejects `opened` immediately.
    let closeRequested: WebSocketCloseInfo | undefined;
    let rejectOpened!: (error: WebsocketError) => void;

    const closeWithInfo = (closeInfo: WebSocketCloseInfo = {}) => {
      if (ws.readyState === WebSocket.CONNECTING) {
        closeRequested = closeInfo;
        rejectOpened(ConnectionError.websocket('Websocket closed before the connection opened'));
      }
      const { closeCode: code, reason } = closeInfo;
      ws.close(code, reason === undefined ? undefined : truncateCloseReason(reason));
    };

    this.opened = new TypedPromise<WebSocketConnection<T>, WebsocketError>((resolve, reject) => {
      rejectOpened = reject;
      const rejectHandler = () => {
        reject(
          ConnectionError.websocket('Encountered websocket error during connection establishment'),
        );
      };
      // Some WebSocket implementations (React Native on iOS, for one) report a handshake that ends
      // before the socket opens as a bare `close` event with no `error` before it. Without this
      // handler `opened` would stay pending forever in that case.
      const closeBeforeOpenHandler = (ev: CloseEvent) => {
        reject(
          ConnectionError.websocket(
            `Websocket closed during connection establishment with code ${ev.code}${
              ev.reason ? `: ${ev.reason}` : ''
            }`,
          ),
        );
      };
      ws.onopen = () => {
        if (closeRequested) {
          // React Native on Android ignored the close() and opened the socket anyway
          closeWithInfo(closeRequested);
          return;
        }
        resolve({
          readable: new ReadableStream<T>({
            start(controller) {
              ws.onmessage = ({ data }) => {
                // workaround for RN behavior, browsers drop these messages already
                if (ws.readyState === WebSocket.OPEN) {
                  controller.enqueue(data);
                }
              };
              ws.onerror = (e) =>
                controller.error(ConnectionError.websocket(getErrorDescription(e, 'websocket')));
              ws.onclose = (ev) => {
                if (ev.wasClean || ev.code === 1000) {
                  controller.close();
                } else {
                  controller.error(
                    ConnectionError.websocket(`WS closed unexpectedly with code ${ev.code}`),
                  );
                }
              };
            },
            cancel: closeWithInfo,
          }),
          writable: new WritableStream<T>({
            write(chunk) {
              ws.send(chunk);
            },
            abort() {
              ws.close();
            },
            close: closeWithInfo,
          }),
          protocol: ws.protocol,
          extensions: ws.extensions,
        });
        ws.removeEventListener('error', rejectHandler);
        ws.removeEventListener('close', closeBeforeOpenHandler);
      };
      ws.addEventListener('error', rejectHandler);
      ws.addEventListener('close', closeBeforeOpenHandler);
    });

    this.closed = new TypedPromise<WebSocketCloseInfo, WebsocketError>((resolve, reject) => {
      const rejectHandler = async () => {
        const closePromise = new TypedPromise<CloseEvent, never>((res) => {
          if (ws.readyState === WebSocket.CLOSED) return;
          else {
            ws.addEventListener(
              'close',
              (closeEv: CloseEvent) => {
                res(closeEv);
              },
              { once: true },
            );
          }
        });
        const reason = await TypedPromise.race([sleep(250), closePromise]);
        if (!reason) {
          reject(
            ConnectionError.websocket(
              'Encountered unspecified websocket error without a timely close event',
            ),
          );
        } else {
          // if we can infer the close reason from the close event then resolve the promise, we don't need to throw
          resolve(reason);
        }
      };
      ws.addEventListener('close', ({ code, reason }) => {
        resolve({ closeCode: code, reason });
        ws.removeEventListener('error', rejectHandler);
      });

      ws.addEventListener('error', rejectHandler);
    });

    if (options.signal) {
      options.signal.onabort = () => closeWithInfo();
    }

    this.close = closeWithInfo;
  }
}

/** `WebSocket.close` throws a `SyntaxError` for a reason longer than this many UTF-8 bytes. */
const MAX_CLOSE_REASON_BYTES = 123;

export function truncateCloseReason(reason: string): string {
  const encoder = new TextEncoder();
  if (encoder.encode(reason).length <= MAX_CLOSE_REASON_BYTES) {
    return reason;
  }
  // cut on code point boundaries, so a multi-byte character is never split
  let truncated = '';
  let bytes = 0;
  for (const char of reason) {
    bytes += encoder.encode(char).length;
    if (bytes > MAX_CLOSE_REASON_BYTES) {
      break;
    }
    truncated += char;
  }
  return truncated;
}
