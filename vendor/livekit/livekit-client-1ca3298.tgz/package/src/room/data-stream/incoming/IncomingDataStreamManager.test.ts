import {
  DataPacket,
  DataStream_ByteHeader,
  DataStream_Chunk,
  DataStream_CompressionType,
  DataStream_Header,
  DataStream_TextHeader,
  DataStream_Trailer,
  Encryption_Type,
} from '@livekit/protocol';
import { describe, expect, it } from 'vitest';
import {
  stubMissingCompressionStreams,
  stubMissingDeflateRawSupport,
} from '../../../test/compressionStreamStubs';
import { deflateRawCompress } from '../compression';
import { DEFAULT_MAX_OPEN_STREAMS_PER_PARTICIPANT, STREAM_CHUNK_SIZE_BYTES } from '../constants';
import IncomingDataStreamManager from './IncomingDataStreamManager';
import type { ByteStreamReader, TextStreamReader } from './StreamReader';

/** Builds a low quality random string of the given length. */
function randomText(length: number): string {
  let s = '';
  while (s.length < length) {
    s += Math.random().toString(36).slice(2);
  }
  return s.slice(0, length);
}

/** Fills a buffer with uniform random bytes — genuinely incompressible. */
function randomBytes(length: number): Uint8Array {
  const out = new Uint8Array(length);
  // crypto.getRandomValues rejects requests over 65536 bytes, so chunk it.
  for (let offset = 0; offset < length; offset += 65536) {
    crypto.getRandomValues(out.subarray(offset, offset + 65536));
  }
  return out;
}

type HeaderFields = NonNullable<ConstructorParameters<typeof DataStream_Header>[0]>;

/** Wraps a `DataStream_Header` (from `alice`, topic `my-topic`) in a `DataPacket`. */
function headerPacket(
  streamId: string,
  contentCase: 'textHeader' | 'byteHeader',
  fields: HeaderFields = {},
): DataPacket {
  return new DataPacket({
    participantIdentity: 'alice',
    value: {
      case: 'streamHeader',
      value: new DataStream_Header({
        streamId,
        topic: 'my-topic',
        mimeType: 'text/plain',
        timestamp: 0n,
        contentHeader:
          contentCase === 'textHeader'
            ? { case: 'textHeader', value: new DataStream_TextHeader({}) }
            : { case: 'byteHeader', value: new DataStream_ByteHeader({}) },
        ...fields,
      }),
    },
  });
}

/** Wraps a `DataStream_Chunk` in a `DataPacket`. */
function chunkPacket(
  streamId: string,
  chunkIndex: number,
  content: Uint8Array,
  version = 0,
): DataPacket {
  return new DataPacket({
    participantIdentity: 'alice',
    value: {
      case: 'streamChunk',
      value: new DataStream_Chunk({
        streamId,
        chunkIndex: BigInt(chunkIndex),
        content,
        version,
      }),
    },
  });
}

/** Wraps a `DataStream_Trailer` in a `DataPacket`. */
function trailerPacket(
  streamId: string,
  attributes?: Record<string, string>,
  reason?: string,
): DataPacket {
  return new DataPacket({
    participantIdentity: 'alice',
    value: {
      case: 'streamTrailer',
      value: new DataStream_Trailer({ streamId, attributes, reason }),
    },
  });
}

/** Concatenates the byte chunks a `ByteStreamReader.readAll()` resolves with. */
function concatChunks(chunks: Array<Uint8Array>): Uint8Array {
  const out = new Uint8Array(chunks.reduce((acc, chunk) => acc + chunk.byteLength, 0));
  let offset = 0;
  for (const chunk of chunks) {
    out.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return out;
}

describe('IncomingDataStreamManager', () => {
  describe('Receiving v1 data streams', () => {
    it('should receive a v1 text data stream', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = 'hello world';

      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: BigInt(text.length),
              attributes: { foo: 'bar' },
              contentHeader: { case: 'textHeader', value: new DataStream_TextHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamChunk',
            value: new DataStream_Chunk({
              streamId,
              chunkIndex: 0n,
              content: new TextEncoder().encode(text),
              version: 0,
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamTrailer',
            value: new DataStream_Trailer({ streamId }),
          },
        }),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual('hello world');
      expect(reader.info.attributes?.foo).toStrictEqual('bar');
    });

    it('should receive a v1 bytes data stream', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<ByteStreamReader>((resolve) => {
        manager.registerByteStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();

      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: 4n,
              attributes: { foo: 'bar' },
              contentHeader: { case: 'byteHeader', value: new DataStream_ByteHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamChunk',
            value: new DataStream_Chunk({
              streamId,
              chunkIndex: 0n,
              content: new Uint8Array([0x01, 0x02, 0x03, 0x04]),
              version: 0,
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamTrailer',
            value: new DataStream_Trailer({ streamId }),
          },
        }),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual([new Uint8Array([0x01, 0x02, 0x03, 0x04])]);
      expect(reader.info.attributes?.foo).toStrictEqual('bar');
    });

    it('should receive a v1 text data stream with files', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const streamId = crypto.randomUUID();
      const streamReaderPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const attachmentStreamId = crypto.randomUUID();
      const attachmentStreamReaderPromise = new Promise<ByteStreamReader>((resolve) => {
        manager.registerByteStreamHandler('my-topic', (reader) => resolve(reader));
      });

      // Send the main data stream body
      const text = 'hello world';
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: BigInt(text.length),
              attributes: { foo: 'bar' },
              inlineContent: new TextEncoder().encode(text),
              contentHeader: {
                case: 'textHeader',
                value: new DataStream_TextHeader({
                  attachedStreamIds: [attachmentStreamId],
                }),
              },
            }),
          },
        }),
        Encryption_Type.NONE,
      );

      // Send an attachment
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId: attachmentStreamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: 3n,
              attributes: {},
              contentHeader: { case: 'byteHeader', value: new DataStream_ByteHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamChunk',
            value: new DataStream_Chunk({
              streamId: attachmentStreamId,
              chunkIndex: 0n,
              content: new Uint8Array([0x01, 0x02, 0x03]),
              version: 0,
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamTrailer',
            value: new DataStream_Trailer({ streamId: attachmentStreamId }),
          },
        }),
        Encryption_Type.NONE,
      );

      const streamReader = await streamReaderPromise;
      expect(await streamReader.readAll()).toStrictEqual('hello world');
      expect(streamReader.info.attachedStreamIds).toHaveLength(1);

      const attachmentStreamReader = await attachmentStreamReaderPromise;
      expect(await attachmentStreamReader.readAll()).toStrictEqual([
        new Uint8Array([0x01, 0x02, 0x03]),
      ]);
      expect(streamReader.info.attachedStreamIds).toHaveLength(1);
    });

    it('should buffer packets when disconnected', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(false);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = 'hello world';

      // Send three packets
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: BigInt(text.length),
              attributes: { foo: 'bar' },
              contentHeader: { case: 'textHeader', value: new DataStream_TextHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamChunk',
            value: new DataStream_Chunk({
              streamId,
              chunkIndex: 0n,
              content: new TextEncoder().encode(text),
              version: 0,
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamTrailer',
            value: new DataStream_Trailer({ streamId }),
          },
        }),
        Encryption_Type.NONE,
      );

      // Make sure promise still hasn't resolved
      await expect(
        Promise.race([readerPromise, Promise.resolve('still pending')]),
      ).resolves.toStrictEqual('still pending');

      // Simulate connecting
      manager.setConnected(true);

      // Make sure it resolves after connected state set
      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual('hello world');
    });

    it('should merge in trailer attributes', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = 'hello world';

      // Send three packets
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: BigInt(text.length),
              attributes: { foo: 'bar', baz: 'quux' },
              contentHeader: { case: 'textHeader', value: new DataStream_TextHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamChunk',
            value: new DataStream_Chunk({
              streamId,
              chunkIndex: 0n,
              content: new TextEncoder().encode(text),
              version: 0,
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamTrailer',
            value: new DataStream_Trailer({
              streamId,
              attributes: { hello: 'world', foo: 'updated' },
            }),
          },
        }),
        Encryption_Type.NONE,
      );

      // Make sure it resolves after connected state set
      const reader = await readerPromise;
      expect(reader.info.attributes?.baz).toStrictEqual('quux');
      expect(reader.info.attributes?.hello).toStrictEqual('world');
      expect(reader.info.attributes?.foo).toStrictEqual('updated');
    });

    it('should drop packets with incorrect EncryptionType', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = 'hello world';

      // Send two packets, the second with an incorrect encryption value
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: BigInt(text.length),
              attributes: { foo: 'bar', baz: 'quux' },
              contentHeader: { case: 'textHeader', value: new DataStream_TextHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamChunk',
            value: new DataStream_Chunk({
              streamId,
              chunkIndex: 0n,
              content: new TextEncoder().encode(text),
              version: 0,
            }),
          },
        }),
        Encryption_Type.GCM, // <-- NOTE: this has changed since the last packet
      );

      // Make sure an error is thrown from the reader
      const reader = await readerPromise;
      expect(() => reader.readAll()).rejects.toThrow('Encryption type mismatch');
    });

    it('should throw an error if data stream does not have enough packets', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();

      // Send a header, a 1 byte long chunk, and a trailer
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: 5n,
              attributes: { foo: 'bar', baz: 'quux' },
              contentHeader: { case: 'textHeader', value: new DataStream_TextHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamChunk',
            value: new DataStream_Chunk({
              streamId,
              chunkIndex: 0n,
              content: new Uint8Array([0x01]),
              version: 0,
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamTrailer',
            value: new DataStream_Trailer({ streamId }),
          },
        }),
        Encryption_Type.NONE,
      );

      // Make sure an error is thrown from the reader
      const reader = await readerPromise;
      await expect(reader.readAll()).rejects.toThrow('Not enough chunk(s)');
    });

    it('should throw an error if data stream has too many bytes', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();

      // Send a header declaring 3 bytes, then a 5 byte long chunk, and a trailer
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: 3n,
              attributes: { foo: 'bar', baz: 'quux' },
              contentHeader: { case: 'textHeader', value: new DataStream_TextHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamChunk',
            value: new DataStream_Chunk({
              streamId,
              chunkIndex: 0n,
              content: new Uint8Array([0x01, 0x02, 0x03, 0x04, 0x05]),
              version: 0,
            }),
          },
        }),
        Encryption_Type.NONE,
      );

      // Make sure an error is thrown from the reader
      const reader = await readerPromise;
      await expect(reader.readAll()).rejects.toThrow('Extra chunk(s)');
    });

    it('should throw an error if participant disconnects while data stream is still not fully received', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();

      // Send a header declaring 10 bytes, then a 5 byte long chunk
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: 10n,
              attributes: { foo: 'bar', baz: 'quux' },
              contentHeader: { case: 'textHeader', value: new DataStream_TextHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamChunk',
            value: new DataStream_Chunk({
              streamId,
              chunkIndex: 0n,
              content: new Uint8Array([0x01, 0x02, 0x03, 0x04, 0x05]),
              version: 0,
            }),
          },
        }),
        Encryption_Type.NONE,
      );

      // Simulate a remote participant disconnect, which calls this method in the room handler
      manager.validateParticipantHasNoActiveDataStreams('alice');

      // Make sure an error is thrown from the reader
      const reader = await readerPromise;
      await expect(reader.readAll()).rejects.toThrow(
        'Participant alice unexpectedly disconnected in the middle of sending data',
      );
    });

    it('should error in flight streams when the controllers are cleared on room disconnect', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const textReaderPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });
      const byteReaderPromise = new Promise<ByteStreamReader>((resolve) => {
        manager.registerByteStreamHandler('my-topic', (reader) => resolve(reader));
      });

      manager.handleDataStreamPacket(headerPacket('text-1', 'textHeader'), Encryption_Type.NONE);
      manager.handleDataStreamPacket(
        chunkPacket('text-1', 0, new Uint8Array([0x68, 0x69])),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(headerPacket('byte-1', 'byteHeader'), Encryption_Type.NONE);
      manager.handleDataStreamPacket(
        chunkPacket('byte-1', 0, new Uint8Array([0x01])),
        Encryption_Type.NONE,
      );

      // Room#handleDisconnect calls this while the streams are still open
      manager.clearControllers();

      const textReader = await textReaderPromise;
      const byteReader = await byteReaderPromise;
      await expect(textReader.readAll()).rejects.toThrow('Room disconnected');
      await expect(byteReader.readAll()).rejects.toThrow('Room disconnected');
    });
  });

  describe('Receiving v2 data streams', () => {
    it('should receive a v2 SINGLE PACKET + UNCOMPRESSED text data stream', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = 'hello world';

      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: BigInt(text.length),
              attributes: { foo: 'bar' },
              inlineContent: new TextEncoder().encode(text),
              contentHeader: { case: 'textHeader', value: new DataStream_TextHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual('hello world');
      expect(reader.info.attributes?.foo).toStrictEqual('bar');
    });

    it('should receive a v2 SINGLE PACKET + UNCOMPRESSED byte data stream', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<ByteStreamReader>((resolve) => {
        manager.registerByteStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const bytes = new Uint8Array([0x01, 0x02, 0x03]);

      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: 3n,
              inlineContent: bytes,
              contentHeader: { case: 'byteHeader', value: new DataStream_ByteHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual([new Uint8Array([0x01, 0x02, 0x03])]);
    });

    it('should receive a v2 SINGLE PACKET + COMPRESSED text data stream', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = 'hello world';
      const compressed = await deflateRawCompress(new TextEncoder().encode(text));

      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: BigInt(text.length),
              attributes: { foo: 'bar' },
              compression: DataStream_CompressionType.DEFLATE_RAW,
              inlineContent: compressed,
              contentHeader: { case: 'textHeader', value: new DataStream_TextHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual('hello world');
      expect(reader.info.attributes?.foo).toStrictEqual('bar');
    });

    it('should receive a v2 SINGLE PACKET + COMPRESSED byte data stream', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<ByteStreamReader>((resolve) => {
        manager.registerByteStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const bytes = new Uint8Array([0x01, 0x02, 0x03]);
      const compressed = await deflateRawCompress(bytes);

      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: BigInt(bytes.length),
              compression: DataStream_CompressionType.DEFLATE_RAW,
              inlineContent: compressed,
              contentHeader: { case: 'byteHeader', value: new DataStream_ByteHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual([new Uint8Array([0x01, 0x02, 0x03])]);
    });

    it('should receive a v2 MULTI PACKET + COMPRESSED text data stream', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();

      // NOTE: mostly incompressible, but the hello world parts repeating should mean that the compressed
      // contents is smaller than the full uncompressed data.
      const text = new Array(30)
        .fill(null)
        .map(() => `hello world${randomText(1_000)}`)
        .join('');

      const compressed = await deflateRawCompress(new TextEncoder().encode(text));

      // Make sure the compressed text should be able to be split into two "packets" worth of data
      expect(compressed.length).toBeLessThan(2 * STREAM_CHUNK_SIZE_BYTES);

      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: BigInt(text.length),
              compression: DataStream_CompressionType.DEFLATE_RAW,
              contentHeader: { case: 'textHeader', value: new DataStream_TextHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamChunk',
            value: new DataStream_Chunk({
              streamId,
              chunkIndex: 0n,
              content: compressed.slice(0, STREAM_CHUNK_SIZE_BYTES),
              version: 0,
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamChunk',
            value: new DataStream_Chunk({
              streamId,
              chunkIndex: 1n,
              content: compressed.slice(STREAM_CHUNK_SIZE_BYTES),
              version: 0,
            }),
          },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamTrailer',
            value: new DataStream_Trailer({ streamId }),
          },
        }),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual(text);
    });

    it.each([
      [`DecompressionStream doesn't exist`, stubMissingCompressionStreams],
      [`deflate-raw isn't a supported format`, stubMissingDeflateRawSupport],
    ])(`should ignore a v2 TEXT data stream with compression if %s`, async (_label, stub) => {
      const text = 'hello world';
      const compressed = await deflateRawCompress(new TextEncoder().encode(text));

      const restoreCompressionStreams = stub();
      try {
        const manager = new IncomingDataStreamManager();
        manager.setConnected(true);

        const readerPromise = new Promise<TextStreamReader>((resolve) => {
          manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
        });

        const streamId = crypto.randomUUID();

        manager.handleDataStreamPacket(
          new DataPacket({
            participantIdentity: 'alice',
            value: {
              case: 'streamHeader',
              value: new DataStream_Header({
                streamId,
                topic: 'my-topic',
                mimeType: 'text/plain',
                timestamp: 0n,
                totalLength: BigInt(text.length),
                compression: DataStream_CompressionType.DEFLATE_RAW,
                contentHeader: { case: 'textHeader', value: new DataStream_TextHeader({}) },
              }),
            },
          }),
          Encryption_Type.NONE,
        );
        manager.handleDataStreamPacket(
          new DataPacket({
            participantIdentity: 'alice',
            value: {
              case: 'streamChunk',
              value: new DataStream_Chunk({
                streamId,
                chunkIndex: 0n,
                content: compressed,
                version: 0,
              }),
            },
          }),
          Encryption_Type.NONE,
        );
        manager.handleDataStreamPacket(
          new DataPacket({
            participantIdentity: 'alice',
            value: {
              case: 'streamTrailer',
              value: new DataStream_Trailer({ streamId }),
            },
          }),
          Encryption_Type.NONE,
        );

        // Make sure promise is still pending; the data stream should have been dropped
        await expect(
          Promise.race([readerPromise, Promise.resolve('still pending')]),
        ).resolves.toStrictEqual('still pending');
      } finally {
        restoreCompressionStreams();
      }
    });

    it.each([
      [`DecompressionStream doesn't exist`, stubMissingCompressionStreams],
      [`deflate-raw isn't a supported format`, stubMissingDeflateRawSupport],
    ])(`should ignore a v2 BYTES data stream with compression if %s`, async (_label, stub) => {
      const bytes = new Uint8Array([0x01, 0x02, 0x03]);
      const compressed = await deflateRawCompress(bytes);

      const restoreCompressionStreams = stub();
      try {
        const manager = new IncomingDataStreamManager();
        manager.setConnected(true);

        const readerPromise = new Promise<ByteStreamReader>((resolve) => {
          manager.registerByteStreamHandler('my-topic', (reader) => resolve(reader));
        });

        const streamId = crypto.randomUUID();

        manager.handleDataStreamPacket(
          new DataPacket({
            participantIdentity: 'alice',
            value: {
              case: 'streamHeader',
              value: new DataStream_Header({
                streamId,
                topic: 'my-topic',
                mimeType: 'application/octet-stream',
                timestamp: 0n,
                totalLength: BigInt(bytes.length),
                compression: DataStream_CompressionType.DEFLATE_RAW,
                contentHeader: { case: 'byteHeader', value: new DataStream_ByteHeader({}) },
              }),
            },
          }),
          Encryption_Type.NONE,
        );
        manager.handleDataStreamPacket(
          new DataPacket({
            participantIdentity: 'alice',
            value: {
              case: 'streamChunk',
              value: new DataStream_Chunk({
                streamId,
                chunkIndex: 0n,
                content: compressed,
                version: 0,
              }),
            },
          }),
          Encryption_Type.NONE,
        );
        manager.handleDataStreamPacket(
          new DataPacket({
            participantIdentity: 'alice',
            value: {
              case: 'streamTrailer',
              value: new DataStream_Trailer({ streamId }),
            },
          }),
          Encryption_Type.NONE,
        );

        // Make sure promise is still pending; the data stream should have been dropped
        await expect(
          Promise.race([readerPromise, Promise.resolve('still pending')]),
        ).resolves.toStrictEqual('still pending');
      } finally {
        restoreCompressionStreams();
      }
    });

    it('should receive a v2 SINGLE PACKET text data stream with zero length', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'text/plain',
              timestamp: 0n,
              totalLength: 0n,
              attributes: { foo: 'bar' },
              inlineContent: new Uint8Array(0), // Empty buffer that is 0 bytes long
              contentHeader: { case: 'textHeader', value: new DataStream_TextHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual('');
      expect(reader.info.attributes?.foo).toStrictEqual('bar');
    });

    it('should receive a v2 SINGLE PACKET byte data stream with zero length', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<ByteStreamReader>((resolve) => {
        manager.registerByteStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      manager.handleDataStreamPacket(
        new DataPacket({
          participantIdentity: 'alice',
          value: {
            case: 'streamHeader',
            value: new DataStream_Header({
              streamId,
              topic: 'my-topic',
              mimeType: 'byte/plain',
              timestamp: 0n,
              totalLength: 0n,
              attributes: { foo: 'bar' },
              inlineContent: new Uint8Array(0), // Empty buffer that is 0 bytes long
              contentHeader: { case: 'byteHeader', value: new DataStream_ByteHeader({}) },
            }),
          },
        }),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual([new Uint8Array(0)]);
      expect(reader.info.attributes?.foo).toStrictEqual('bar');
    });

    it('should receive a v2 MULTI PACKET + COMPRESSED byte data stream', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<ByteStreamReader>((resolve) => {
        manager.registerByteStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      // Incompressible, so the compressed form stays large enough to need two chunks (but fewer
      // than three).
      const bytes = randomBytes(20_000);
      const compressed = await deflateRawCompress(bytes);
      expect(compressed.length).toBeGreaterThan(STREAM_CHUNK_SIZE_BYTES);
      expect(compressed.length).toBeLessThan(2 * STREAM_CHUNK_SIZE_BYTES);

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'byteHeader', {
          totalLength: BigInt(bytes.length),
          compression: DataStream_CompressionType.DEFLATE_RAW,
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, compressed.slice(0, STREAM_CHUNK_SIZE_BYTES)),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 1, compressed.slice(STREAM_CHUNK_SIZE_BYTES)),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE);

      const reader = await readerPromise;
      expect(concatChunks(await reader.readAll())).toStrictEqual(bytes);
    });

    it('should drop a duplicate chunk index on a compressed stream and still decode', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = new Array(30)
        .fill(null)
        .map(() => `hello world${randomText(1_000)}`)
        .join('');
      const compressed = await deflateRawCompress(new TextEncoder().encode(text));
      expect(compressed.length).toBeGreaterThan(STREAM_CHUNK_SIZE_BYTES);
      expect(compressed.length).toBeLessThan(2 * STREAM_CHUNK_SIZE_BYTES);

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', {
          totalLength: BigInt(text.length),
          compression: DataStream_CompressionType.DEFLATE_RAW,
        }),
        Encryption_Type.NONE,
      );
      const chunk0 = chunkPacket(streamId, 0, compressed.slice(0, STREAM_CHUNK_SIZE_BYTES));
      manager.handleDataStreamPacket(chunk0, Encryption_Type.NONE);
      // A replayed chunk (e.g. reconnect logic) must be dropped with a warning, not fed to the
      // stateful decompressor a second time.
      manager.handleDataStreamPacket(chunk0, Encryption_Type.NONE);
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 1, compressed.slice(STREAM_CHUNK_SIZE_BYTES)),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE);

      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual(text);
    });

    it('should error on a gap in chunk indices on a compressed stream', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = new Array(30)
        .fill(null)
        .map(() => `hello world${randomText(1_000)}`)
        .join('');
      const compressed = await deflateRawCompress(new TextEncoder().encode(text));

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', {
          totalLength: BigInt(text.length),
          compression: DataStream_CompressionType.DEFLATE_RAW,
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, compressed.slice(0, STREAM_CHUNK_SIZE_BYTES)),
        Encryption_Type.NONE,
      );
      // Skip chunk index 1 entirely — the stateful decompressor cannot continue past a gap.
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 2, compressed.slice(STREAM_CHUNK_SIZE_BYTES)),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      await expect(reader.readAll()).rejects.toThrow('Missing chunk(s)');

      // The errored stream must be unregistered, so packets still in flight for it are dropped
      // instead of throwing on a closed controller (#2166).
      expect(() =>
        manager.handleDataStreamPacket(
          chunkPacket(streamId, 3, new Uint8Array([1])),
          Encryption_Type.NONE,
        ),
      ).not.toThrow();
      expect(() =>
        manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE),
      ).not.toThrow();
    });

    it('should error on a gap in chunk indices on an uncompressed text stream', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = randomText(3_000);
      const textBytes = new TextEncoder().encode(text);
      const split = Math.floor(textBytes.length / 3);

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', {
          totalLength: BigInt(textBytes.length),
          compression: DataStream_CompressionType.NONE,
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, textBytes.slice(0, split)),
        Encryption_Type.NONE,
      );
      // Skip chunk index 1 entirely — a gap means the payload cannot be reassembled in order.
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 2, textBytes.slice(split)),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      await expect(reader.readAll()).rejects.toThrow('Missing chunk(s)');

      // The errored stream must be unregistered, so packets still in flight for it are dropped
      // instead of throwing on a closed controller (#2166).
      expect(() =>
        manager.handleDataStreamPacket(
          chunkPacket(streamId, 3, new Uint8Array([1])),
          Encryption_Type.NONE,
        ),
      ).not.toThrow();
      expect(() =>
        manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE),
      ).not.toThrow();
    });

    it('should error on a gap in chunk indices on an uncompressed byte stream', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<ByteStreamReader>((resolve) => {
        manager.registerByteStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const bytes = randomBytes(3_000);
      const split = Math.floor(bytes.length / 3);

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'byteHeader', {
          totalLength: BigInt(bytes.length),
          compression: DataStream_CompressionType.NONE,
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, bytes.slice(0, split)),
        Encryption_Type.NONE,
      );
      // Skip chunk index 1 entirely.
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 2, bytes.slice(split)),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      await expect(reader.readAll()).rejects.toThrow('Missing chunk(s)');

      // The errored stream must be unregistered, so packets still in flight for it are dropped
      // instead of throwing on a closed controller (#2166).
      expect(() =>
        manager.handleDataStreamPacket(
          chunkPacket(streamId, 3, new Uint8Array([1])),
          Encryption_Type.NONE,
        ),
      ).not.toThrow();
      expect(() =>
        manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE),
      ).not.toThrow();
    });

    it('should drop a duplicate chunk index on an uncompressed text stream and still decode', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = randomText(3_000);
      const textBytes = new TextEncoder().encode(text);
      const split = Math.floor(textBytes.length / 2);

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', {
          totalLength: BigInt(textBytes.length),
          compression: DataStream_CompressionType.NONE,
        }),
        Encryption_Type.NONE,
      );
      const chunk0 = chunkPacket(streamId, 0, textBytes.slice(0, split));
      manager.handleDataStreamPacket(chunk0, Encryption_Type.NONE);
      // A replayed chunk (e.g. reconnect logic) must be dropped with a warning, not appended a
      // second time — otherwise the payload is corrupted and exceeds `totalLength`.
      manager.handleDataStreamPacket(chunk0, Encryption_Type.NONE);
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 1, textBytes.slice(split)),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE);

      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual(text);
    });

    it('should drop a duplicate chunk index on an uncompressed byte stream and still decode', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<ByteStreamReader>((resolve) => {
        manager.registerByteStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const bytes = randomBytes(3_000);
      const split = Math.floor(bytes.length / 2);

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'byteHeader', {
          totalLength: BigInt(bytes.length),
          compression: DataStream_CompressionType.NONE,
        }),
        Encryption_Type.NONE,
      );
      const chunk0 = chunkPacket(streamId, 0, bytes.slice(0, split));
      manager.handleDataStreamPacket(chunk0, Encryption_Type.NONE);
      manager.handleDataStreamPacket(chunk0, Encryption_Type.NONE);
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 1, bytes.slice(split)),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE);

      const reader = await readerPromise;
      expect(concatChunks(await reader.readAll())).toStrictEqual(bytes);
    });

    it('should drop chunks resent at an already-received index', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = 'hello world';
      const textBytes = new TextEncoder().encode(text);

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', { totalLength: BigInt(textBytes.length) }),
        Encryption_Type.NONE,
      );
      // first assuring a version going from 1 -> 2 works as expected
      manager.handleDataStreamPacket(chunkPacket(streamId, 0, textBytes, 1), Encryption_Type.NONE);
      // Chunk-level `version` retcon is not supported: a reader that has already yielded chunk 0 to
      // its consumer cannot retract it, so a resend at the same index is dropped like any other
      // duplicate rather than superseding the original. See the note on
      // `TextStreamReader.handleChunkReceived`.
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, new TextEncoder().encode('goodbye world'), 2),
        Encryption_Type.NONE,
      );
      // sending a lower version number again to ensure this one also gets dropped
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, new TextEncoder().encode('goodbye world'), 0),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE);

      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual(text);
    });

    it('should reframe multibyte UTF-8 on chunk boundaries when decompressing a text stream', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = '😀你好世界 café — ¡ñandú! '.repeat(500);
      const textBytes = new TextEncoder().encode(text);
      const compressed = await deflateRawCompress(textBytes);

      // Split the compressed bytes at an arbitrary midpoint: the decompressor's output at the
      // seam can land mid-codepoint, exercising the UTF-8 reframing stage.
      const split = Math.floor(compressed.length / 2);

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', {
          totalLength: BigInt(textBytes.length), // NOTE: byte length, not character count
          compression: DataStream_CompressionType.DEFLATE_RAW,
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, compressed.slice(0, split)),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 1, compressed.slice(split)),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE);

      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual(text);
    });

    it('should error when a compressed stream decompresses to fewer bytes than totalLength', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const compressed = await deflateRawCompress(new TextEncoder().encode('hello world')); // 11 bytes

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', {
          totalLength: 16n, // more than the decompressed payload
          compression: DataStream_CompressionType.DEFLATE_RAW,
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(chunkPacket(streamId, 0, compressed), Encryption_Type.NONE);
      manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE);

      // The reader counts DECOMPRESSED bytes against totalLength.
      const reader = await readerPromise;
      await expect(reader.readAll()).rejects.toThrow('Not enough chunk(s)');
    });

    it('should error when a compressed stream decompresses to more bytes than totalLength', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const compressed = await deflateRawCompress(new TextEncoder().encode('hello world')); // 11 bytes

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', {
          totalLength: 5n, // fewer than the decompressed payload
          compression: DataStream_CompressionType.DEFLATE_RAW,
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(chunkPacket(streamId, 0, compressed), Encryption_Type.NONE);
      manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE);

      const reader = await readerPromise;
      await expect(reader.readAll()).rejects.toThrow('Extra chunk(s)');
    });

    it.each([
      ['UNCOMPRESSED', DataStream_CompressionType.NONE],
      ['COMPRESSED', DataStream_CompressionType.DEFLATE_RAW],
    ])(
      'should hold a v2 SINGLE PACKET + %s payload to its declared totalLength',
      async (_, compression) => {
        /** Reads an inline text stream that carries `text` and declares `totalLength`. */
        const readInlineText = async (text: string, totalLength?: bigint) => {
          const manager = new IncomingDataStreamManager();
          manager.setConnected(true);

          const readerPromise = new Promise<TextStreamReader>((resolve) => {
            manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
          });

          const encoded = new TextEncoder().encode(text);
          manager.handleDataStreamPacket(
            headerPacket(crypto.randomUUID(), 'textHeader', {
              totalLength,
              compression,
              inlineContent:
                compression === DataStream_CompressionType.DEFLATE_RAW
                  ? await deflateRawCompress(encoded)
                  : encoded,
            }),
            Encryption_Type.NONE,
          );

          const reader = await readerPromise;
          return reader.readAll();
        };

        await expect(readInlineText('hello', 6n)).rejects.toThrow('Not enough chunk(s)');
        await expect(readInlineText('hello', 4n)).rejects.toThrow('Extra chunk(s)');
        await expect(readInlineText('hello', 5n)).resolves.toStrictEqual('hello');
        await expect(readInlineText('hello')).resolves.toStrictEqual('hello');
      },
    );

    it('should merge trailer attributes on a compressed stream', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = 'hello world';
      const compressed = await deflateRawCompress(new TextEncoder().encode(text));

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', {
          totalLength: BigInt(text.length),
          compression: DataStream_CompressionType.DEFLATE_RAW,
          attributes: { foo: 'bar', baz: 'quux' },
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(chunkPacket(streamId, 0, compressed), Encryption_Type.NONE);
      manager.handleDataStreamPacket(
        trailerPacket(streamId, { hello: 'world', foo: 'updated' }),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual(text);
      expect(reader.info.attributes?.baz).toStrictEqual('quux');
      expect(reader.info.attributes?.hello).toStrictEqual('world');
      expect(reader.info.attributes?.foo).toStrictEqual('updated');
    });

    it('should ignore a stream with an unknown compression type', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = 'hello world';

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', {
          totalLength: BigInt(text.length),
          compression: 99 as DataStream_CompressionType,
        }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, new TextEncoder().encode(text)),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE);

      // A compression type from a future protocol version can't be decoded; the stream is
      // dropped and the handler is never invoked.
      await expect(
        Promise.race([readerPromise, Promise.resolve('still pending')]),
      ).resolves.toStrictEqual('still pending');
    });
  });

  describe('Receive-side protocol edge cases', () => {
    it('should reject a duplicate TEXT streamId whose stream is already open', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readers: Array<TextStreamReader> = [];
      manager.registerTextStreamHandler('my-topic', (reader) => readers.push(reader));

      const streamId = crypto.randomUUID();
      const header = headerPacket(streamId, 'textHeader', { totalLength: 11n });

      manager.handleDataStreamPacket(header, Encryption_Type.NONE);
      expect(readers).toHaveLength(1);

      // A second header re-using an open streamId must be rejected, not silently replace (or
      // corrupt) the in-flight stream.
      expect(() => manager.handleDataStreamPacket(header, Encryption_Type.NONE)).toThrow(
        'already in progress',
      );
      expect(readers).toHaveLength(1);
    });

    it('should reject a duplicate BYTE streamId whose stream is already open', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readers: Array<ByteStreamReader> = [];
      manager.registerByteStreamHandler('my-topic', (reader) => readers.push(reader));

      const streamId = crypto.randomUUID();
      const header = headerPacket(streamId, 'byteHeader', { totalLength: 4n });

      manager.handleDataStreamPacket(header, Encryption_Type.NONE);
      expect(readers).toHaveLength(1);

      expect(() => manager.handleDataStreamPacket(header, Encryption_Type.NONE)).toThrow(
        'already in progress',
      );
      expect(readers).toHaveLength(1);
    });

    it('should ignore empty chunks', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = 'hello world';

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', { totalLength: BigInt(text.length) }),
        Encryption_Type.NONE,
      );
      // An empty chunk must not count against totalLength or corrupt the stream.
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, new Uint8Array(0)),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 1, new TextEncoder().encode(text)),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE);

      const reader = await readerPromise;
      expect(await reader.readAll()).toStrictEqual(text);
    });

    it('should silently drop packets for a topic with no registered handler', () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const streamId = crypto.randomUUID();

      // No handler registered for the topic: header, chunks, and trailer are all dropped
      // without raising.
      expect(() => {
        manager.handleDataStreamPacket(
          headerPacket(streamId, 'textHeader', { totalLength: 11n }),
          Encryption_Type.NONE,
        );
        manager.handleDataStreamPacket(
          chunkPacket(streamId, 0, new TextEncoder().encode('hello world')),
          Encryption_Type.NONE,
        );
        manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE);
      }).not.toThrow();
    });

    it('should error the reader when the trailer reports an abnormal close reason', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = 'hello world';

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', { totalLength: BigInt(text.length) }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, new TextEncoder().encode(text)),
        Encryption_Type.NONE,
      );
      // A non-empty trailer reason means the sender aborted; the stream must not be reported as
      // a successful close.
      manager.handleDataStreamPacket(
        trailerPacket(streamId, undefined, 'cancelled'),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      await expect(reader.readAll()).rejects.toThrow('closed abnormally: cancelled');
    });

    it('should error with the trailer reason when a stream closes before the specified totalLength', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = 'hello world';

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', { totalLength: BigInt(text.length * 2) }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, new TextEncoder().encode(text)),
        Encryption_Type.NONE,
      );
      // The sender stops halfway and gives a reason; that reason, not the missing bytes, is the
      // error the reader gets.
      manager.handleDataStreamPacket(
        trailerPacket(streamId, undefined, 'cancelled'),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      await expect(reader.readAll()).rejects.toThrow('closed abnormally: cancelled');
    });

    it('should error an inline compressed payload that inflates past the max payload size', async () => {
      // Decompression-bomb guard: a tiny compressed inline payload must not be allowed to
      // expand without bound.
      const manager = new IncomingDataStreamManager({ maxPayloadByteLength: 1_000 });
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = randomText(50_000);
      const textBytes = new TextEncoder().encode(text);
      const compressed = await deflateRawCompress(textBytes);

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', {
          totalLength: BigInt(textBytes.length),
          compression: DataStream_CompressionType.DEFLATE_RAW,
          inlineContent: compressed,
        }),
        Encryption_Type.NONE,
      );

      const reader = await readerPromise;
      await expect(reader.readAll()).rejects.toThrow('maximum payload size');
    });

    it('should error a chunked compressed stream that inflates past the max payload size', async () => {
      const manager = new IncomingDataStreamManager({ maxPayloadByteLength: 50_000 });
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = randomText(60_000); // decompresses past the 50k cap
      const textBytes = new TextEncoder().encode(text);
      const compressed = await deflateRawCompress(textBytes);

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', {
          totalLength: BigInt(textBytes.length),
          compression: DataStream_CompressionType.DEFLATE_RAW,
        }),
        Encryption_Type.NONE,
      );
      for (let offset = 0, index = 0; offset < compressed.length; offset += 15_000, index += 1) {
        manager.handleDataStreamPacket(
          chunkPacket(streamId, index, compressed.slice(offset, offset + 15_000)),
          Encryption_Type.NONE,
        );
      }
      manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE);

      const reader = await readerPromise;
      await expect(reader.readAll()).rejects.toThrow('maximum payload size');
    });

    it('should error the reader when the trailer has a mismatched encryption type', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readerPromise = new Promise<TextStreamReader>((resolve) => {
        manager.registerTextStreamHandler('my-topic', (reader) => resolve(reader));
      });

      const streamId = crypto.randomUUID();
      const text = 'hello world';

      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', { totalLength: BigInt(text.length) }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, new TextEncoder().encode(text)),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.GCM);

      const reader = await readerPromise;
      await expect(reader.readAll()).rejects.toThrow('Encryption type mismatch');
    });

    it('should treat packets for a stream that errored on a chunk index gap as an unknown stream (#2166)', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readers: Array<TextStreamReader> = [];
      manager.registerTextStreamHandler('my-topic', (reader) => readers.push(reader));

      const streamId = crypto.randomUUID();
      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', { compression: DataStream_CompressionType.NONE }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, new TextEncoder().encode('first')),
        Encryption_Type.NONE,
      );
      // Skip chunk index 1, which errors the stream.
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 2, new TextEncoder().encode('third')),
        Encryption_Type.NONE,
      );
      expect(readers).toHaveLength(1);
      await expect(readers[0].readAll()).rejects.toThrow('Missing chunk(s)');

      // Packets still in flight for the errored stream are dropped, just like packets for a stream
      // that was never opened, rather than throwing on a closed controller.
      expect(() =>
        manager.handleDataStreamPacket(
          chunkPacket(streamId, 3, new TextEncoder().encode('fourth')),
          Encryption_Type.NONE,
        ),
      ).not.toThrow();
      expect(() =>
        manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE),
      ).not.toThrow();
      expect(readers).toHaveLength(1);

      // No state is left behind for the stream id: a header reusing it opens a brand new stream
      // instead of failing with `AlreadyOpened`, and that stream reads cleanly from chunk 0.
      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', { compression: DataStream_CompressionType.NONE }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, new TextEncoder().encode('fresh stream')),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE);

      expect(readers).toHaveLength(2);
      expect(await readers[1].readAll()).toEqual('fresh stream');
    });

    it('should treat packets for a stream whose read was aborted as an unknown stream', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readers: Array<TextStreamReader> = [];
      manager.registerTextStreamHandler('my-topic', (reader) => readers.push(reader));

      const streamId = crypto.randomUUID();
      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', { compression: DataStream_CompressionType.NONE }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, new TextEncoder().encode('first')),
        Encryption_Type.NONE,
      );
      expect(readers).toHaveLength(1);

      // The consumer gives up on the stream part way through.
      const abortController = new AbortController();
      const readAllPromise = readers[0].readAll({ signal: abortController.signal });
      abortController.abort(new Error('consumer aborted'));
      await expect(readAllPromise).rejects.toThrow('consumer aborted');
      // The cancel propagates back up the pipe chain to the source stream asynchronously.
      await new Promise((resolve) => setTimeout(resolve, 0));

      // Packets still in flight for the aborted stream are dropped, just like packets for a stream
      // that was never opened, rather than buffering in a stream nobody reads.
      expect(() =>
        manager.handleDataStreamPacket(
          chunkPacket(streamId, 1, new TextEncoder().encode('second')),
          Encryption_Type.NONE,
        ),
      ).not.toThrow();
      expect(readers).toHaveLength(1);

      // No state is left behind for the stream id, even though no trailer has arrived to close it: a
      // header reusing it opens a brand new stream instead of failing with `AlreadyOpened`, and that
      // stream reads cleanly from chunk 0.
      manager.handleDataStreamPacket(
        headerPacket(streamId, 'textHeader', { compression: DataStream_CompressionType.NONE }),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(
        chunkPacket(streamId, 0, new TextEncoder().encode('fresh stream')),
        Encryption_Type.NONE,
      );
      manager.handleDataStreamPacket(trailerPacket(streamId), Encryption_Type.NONE);

      expect(readers).toHaveLength(2);
      expect(await readers[1].readAll()).toEqual('fresh stream');
    });

    it('drops headers from a participant that already has the maximum number of streams open', async () => {
      const manager = new IncomingDataStreamManager();
      manager.setConnected(true);

      const readers: Array<TextStreamReader> = [];
      manager.registerTextStreamHandler('my-topic', (reader) => readers.push(reader));

      // Fill alice's quota with streams that are never closed.
      const aliceStreamIds = Array.from({ length: DEFAULT_MAX_OPEN_STREAMS_PER_PARTICIPANT }, () =>
        crypto.randomUUID(),
      );
      for (const streamId of aliceStreamIds) {
        manager.handleDataStreamPacket(headerPacket(streamId, 'textHeader'), Encryption_Type.NONE);
      }
      expect(readers).toHaveLength(DEFAULT_MAX_OPEN_STREAMS_PER_PARTICIPANT);

      // One more from alice is dropped.
      manager.handleDataStreamPacket(
        headerPacket(crypto.randomUUID(), 'textHeader'),
        Encryption_Type.NONE,
      );
      expect(readers).toHaveLength(DEFAULT_MAX_OPEN_STREAMS_PER_PARTICIPANT);

      // The limit is per participant, so bob can still open a stream.
      const bobHeader = headerPacket(crypto.randomUUID(), 'textHeader');
      bobHeader.participantIdentity = 'bob';
      manager.handleDataStreamPacket(bobHeader, Encryption_Type.NONE);
      expect(readers).toHaveLength(DEFAULT_MAX_OPEN_STREAMS_PER_PARTICIPANT + 1);

      // Once one of alice's streams closes, she can open a new one.
      manager.handleDataStreamPacket(trailerPacket(aliceStreamIds[0]), Encryption_Type.NONE);
      expect(await readers[0].readAll()).toEqual('');
      manager.handleDataStreamPacket(
        headerPacket(crypto.randomUUID(), 'textHeader'),
        Encryption_Type.NONE,
      );
      expect(readers).toHaveLength(DEFAULT_MAX_OPEN_STREAMS_PER_PARTICIPANT + 2);
    });

    it('respects a custom per participant open stream limit', () => {
      const manager = new IncomingDataStreamManager({ maxOpenStreamsPerParticipant: 2 });
      manager.setConnected(true);

      const readers: Array<TextStreamReader> = [];
      manager.registerTextStreamHandler('my-topic', (reader) => readers.push(reader));

      for (let i = 0; i < 3; i++) {
        manager.handleDataStreamPacket(
          headerPacket(crypto.randomUUID(), 'textHeader'),
          Encryption_Type.NONE,
        );
      }
      expect(readers).toHaveLength(2);
    });
  });
});
