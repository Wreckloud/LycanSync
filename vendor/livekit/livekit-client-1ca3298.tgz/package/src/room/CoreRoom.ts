import { Mutex } from '@livekit/mutex';
import {
  ClientInfo_Capability,
  ConnectionQualityUpdate,
  type DataPacket,
  DataPacket_Kind,
  DisconnectReason,
  Encryption_Type,
  JoinResponse,
  LeaveRequest,
  LeaveRequest_Action,
  MetricsBatch,
  ParticipantInfo,
  ParticipantInfo_State,
  ParticipantPermission,
  PublishDataTrackResponse,
  Room as RoomModel,
  ServerInfo,
  SimulateScenario,
  SipDTMF,
  SpeakerInfo,
  StreamStateUpdate,
  SubscriptionError,
  SubscriptionPermissionUpdate,
  SubscriptionResponse,
  Transcription as TranscriptionModel,
  TranscriptionSegment as TranscriptionSegmentModel,
  UserPacket,
} from '@livekit/protocol';
import { EventEmitter } from 'events';
import type TypedEmitter from 'typed-emitter';
import { ensureTrailingSlash } from '../api/utils';
import { isFrameMetadataSupported } from '../frameMetadata/utils';
import log, { LoggerNames, getLogger } from '../logger';
import type {
  CoreRoomOptions,
  InternalRoomConnectOptions,
  InternalRoomOptions,
  RoomConnectOptions,
} from '../options';
import type { NonSharedUint8Array } from '../type-polyfills/non-shared-typed-arrays';
import TypedPromise from '../utils/TypedPromise';
import { getBrowser } from '../utils/browserParser';
import { BackOffStrategy } from './BackOffStrategy';
import DeviceManager from './DeviceManager';
import RTCEngine, { type RegionStrategy } from './RTCEngine';
import { DEFAULT_MAX_AGE_MS, RegionUrlProvider } from './RegionUrlProvider';
import type { DataChannelKind } from './data-channel/types';
import type LocalDataTrack from './data-track/LocalDataTrack';
import type RemoteDataTrack from './data-track/RemoteDataTrack';
import type { DataTrackSid } from './data-track/types';
import {
  audioDefaults,
  publishDefaults,
  roomConnectOptionDefaults,
  roomOptionDefaults,
} from './defaults';
import {
  ConnectionError,
  ConnectionErrorReason,
  UnexpectedConnectionState,
  UnsupportedServer,
  canFailOverToAnotherRegion,
} from './errors';
import { EngineEvent, ParticipantEvent, RoomEvent, TrackEvent } from './events';
import type {
  CoreSlots,
  DataPacketCase,
  ExtensionContext,
  ExtensionResult,
  RoomExtension,
} from './extensions';
import { SLOT_KEYS } from './extensions';
import { LocalParticipant } from './participant/LocalParticipant';
import Participant from './participant/Participant';
import { type ConnectionQuality, ParticipantKind } from './participant/Participant';
import RemoteParticipant from './participant/RemoteParticipant';
import { summarizeStatsReport } from './statsSummary';
import CriticalTimers from './timers';
import type LocalAudioTrack from './track/LocalAudioTrack';
import type LocalTrack from './track/LocalTrack';
import LocalTrackPublication from './track/LocalTrackPublication';
import type RemoteTrack from './track/RemoteTrack';
import RemoteTrackPublication from './track/RemoteTrackPublication';
import { Track } from './track/Track';
import type { TrackPublication } from './track/TrackPublication';
import type { TrackProcessor } from './track/processor/types';
import type { AdaptiveStreamSettings } from './track/types';
import { getNewAudioContext, kindToSource, sourceToKind } from './track/utils';
import { type ChatMessage, type SimulationScenario, type TranscriptionSegment } from './types';
import {
  Future,
  extractTrackSid,
  extractTranscriptionSegments,
  getDisconnectReasonFromConnectionError,
  getEmptyAudioStreamTrack,
  isBrowserSupported,
  isCloud,
  isDeflateRawCompressionSupported,
  isLocalAudioTrack,
  isLocalVideoTrack,
  isReactNative,
  isRemotePub,
  isSafariBased,
  isWeb,
  numberToBigInt,
  releaseEmptyAudioStreamTrack,
  sleep,
  supportsSetSinkId,
  toHttpUrl,
  unpackStreamId,
  unwrapConstraint,
} from './utils';

export enum ConnectionState {
  Disconnected = 'disconnected',
  Connecting = 'connecting',
  Connected = 'connected',
  Reconnecting = 'reconnecting',
  SignalReconnecting = 'signalReconnecting',
}

const CONNECTION_RECONCILE_FREQUENCY_MS = 4 * 1000;
const STATS_LOG_FREQUENCY_MS = 30 * 1000;

const DUMMY_AUDIO_ELEMENT_ID = 'livekit-dummy-audio-el';

/**
 * One silent audio element serves every room on the page, so it is reference counted: a room
 * disconnecting must not pull it out from under the rooms still playing through it. The element
 * and its track go away once the last room hands its reference back.
 */
let sharedDummyAudioElement:
  | { element: HTMLAudioElement; stream: MediaStream; track: MediaStreamTrack; refCount: number }
  | undefined;

function createSharedDummyAudioElement() {
  const element = document.createElement('audio');
  element.id = DUMMY_AUDIO_ELEMENT_ID;
  element.autoplay = true;
  element.hidden = true;
  const track = getEmptyAudioStreamTrack();
  track.enabled = true;
  const stream = new MediaStream([track]);
  element.srcObject = stream;
  document.body.append(element);
  return { element, stream, track, refCount: 0 };
}

/**
 * The room without optional features. Use `CoreRoom.with(...extensions)` to build a room class
 * with the features an application needs, or use `Room` from the main entry for all of them.
 *
 * In LiveKit, a room is the logical grouping for a list of participants.
 * Participants in a room can publish tracks, and subscribe to others' tracks.
 *
 * a Room fires [[RoomEvent | RoomEvents]].
 *
 * @noInheritDoc
 * @experimental
 */
export class CoreRoom extends (EventEmitter as new () => TypedEmitter<RoomEventCallbacks>) {
  state: ConnectionState = ConnectionState.Disconnected;

  /**
   * map of identity: [[RemoteParticipant]]
   */
  remoteParticipants: Map<string, RemoteParticipant>;

  /**
   * list of participants that are actively speaking. when this changes
   * a [[RoomEvent.ActiveSpeakersChanged]] event is fired
   */
  activeSpeakers: Participant[] = [];

  /**
   * @internal
   */
  engine!: RTCEngine;

  /** the current participant */
  localParticipant: LocalParticipant;

  /** options of room */
  options: InternalRoomOptions;

  /** reflects the sender encryption status of the local participant */
  isE2EEEnabled: boolean = false;

  serverInfo?: Partial<ServerInfo>;

  private roomInfo?: RoomModel;

  private sidToIdentity: Map<string, string>;

  /** connect options of room */
  private connOptions?: InternalRoomConnectOptions;

  private audioEnabled = true;

  private audioContext?: AudioContext;

  /**
   * whether `audioContext` was created by the SDK and therefore has to be closed by it.
   * A context handed in through `webAudioMix` is owned by the application instead.
   */
  private ownsAudioContext = false;

  /**
   * set once the audio context has been released as part of a disconnect. Guards against
   * creating a new context outside of a connection lifecycle, where nothing would close it again.
   */
  private audioContextReleased = false;

  /**
   * serialises `acquireAudioContext` against `releaseAudioContext`. Both await per-track graph
   * rebuilds, so without it a reconnect landing inside a disconnect's teardown leaves the two
   * racing to set the participants' context, and the loser's value is the one that sticks.
   */
  private audioContextMutex: Mutex = new Mutex();

  /** tears down the iOS dummy audio element, set while one is in place. See `startAudio` */
  private releaseDummyAudioElement?: () => void;

  /** silent audio tracks this room acquired, handed back to the shared source on disconnect */
  private acquiredEmptyAudioTracks = new Set<MediaStreamTrack>();

  /** used for aborting pending connections to a LiveKit server */
  private abortController?: AbortController;

  /** future holding client initiated connection attempt */
  private connectFuture?: Future<void, Error>;

  private disconnectLock: Mutex;

  /** the E2EE manager slot; filled by the `e2ee` extension */

  private connectionReconcileInterval?: ReturnType<typeof setInterval>;

  private statsLogInterval?: ReturnType<typeof setInterval>;

  private regionUrlProvider?: RegionUrlProvider;

  private regionUrl?: string;

  private isVideoPlaybackBlocked: boolean = false;

  private log = log;

  private statsLog = log;

  private bufferedEvents: Array<any> = [];

  /**
   * the room as it was before the current full reconnect. Every region the full reconnect tries
   * starts from it, so the region it connects to reports every change since the outage
   */
  private roomInfoBeforeRestart?: RoomModel;

  private isResuming: boolean = false;

  private pendingTrackAddedCallbacks = new Map<Track.SID, Set<() => void>>();

  /**
   * map to store first point in time when a particular transcription segment was received
   */
  private transcriptionReceivedTimes: Map<string, number>;

  private installedExtensions = new Map<symbol, ExtensionResult<any, any>>();

  /** Values extensions hand to core (the `*Provider` members of an install result); shared with the local participant. */

  private readonly slots: Partial<CoreSlots> = {};

  private extensionDisposers: Array<() => void> = [];

  private dataPacketHandlers = new Map<
    DataPacketCase,
    (
      packet: DataPacket,
      encryptionType: Encryption_Type,
      participant: RemoteParticipant | undefined,
    ) => void
  >();

  /** aborts the `devicechange` listener; also reachable from the FinalizationRegistry callback */
  private cleanupController?: AbortController;

  private disposed = false;

  get hasE2EESetup(): boolean {
    return this.slots.e2eeManager !== undefined;
  }

  /**
   * Creates a new Room, the primary construct for a LiveKit session.
   * @param options
   */
  constructor(options?: CoreRoomOptions) {
    super();
    this.setMaxListeners(100);
    this.remoteParticipants = new Map();
    this.sidToIdentity = new Map();
    this.options = { ...roomOptionDefaults, ...options };

    this.log = getLogger(this.options.loggerName ?? LoggerNames.Room, () => this.logContext);
    // its own logger name, so the stats dumps can be silenced or routed
    // separately from the rest of the room's logs
    this.statsLog = getLogger(LoggerNames.Stats, () => this.logContext);
    this.transcriptionReceivedTimes = new Map();

    this.options.audioCaptureDefaults = {
      ...audioDefaults,
      ...options?.audioCaptureDefaults,
    };
    this.options.videoCaptureDefaults = {
      ...options?.videoCaptureDefaults,
    };
    this.options.publishDefaults = {
      ...publishDefaults,
      ...options?.publishDefaults,
    };

    this.maybeCreateEngine();

    this.disconnectLock = new Mutex();
    this.localParticipant = new LocalParticipant('', '', this.engine, this.options, this.slots);

    if (this.options.videoCaptureDefaults.deviceId) {
      this.localParticipant.activeDeviceMap.set(
        'videoinput',
        unwrapConstraint(this.options.videoCaptureDefaults.deviceId),
      );
    }
    if (this.options.audioCaptureDefaults.deviceId) {
      this.localParticipant.activeDeviceMap.set(
        'audioinput',
        unwrapConstraint(this.options.audioCaptureDefaults.deviceId),
      );
    }
    if (this.options.audioOutput?.deviceId) {
      this.switchActiveDevice(
        'audiooutput',
        unwrapConstraint(this.options.audioOutput.deviceId),
      ).catch((e) => this.log.warn(`Could not set audio output: ${e.message}`));
    }

    if (isWeb()) {
      const cleanupController = new AbortController();
      this.cleanupController = cleanupController;
      let onDeviceChange: () => void;

      const cleanupRegistry = (this.constructor as typeof CoreRoom).cleanupRegistry;
      if (cleanupRegistry) {
        // Wrap the listener in a WeakRef closure so navigator.mediaDevices does not
        // strongly retain the Room. When the user drops their Room ref, the
        // FinalizationRegistry callback aborts the controller and removes the listener.
        onDeviceChange = CoreRoom.createWeakDeviceChangeListener(new WeakRef(this));
        cleanupRegistry.register(this, cleanupController);
      } else {
        // Legacy browsers without WeakRef/FinalizationRegistry: fall back to a
        // direct listener (matches pre-#1944 behavior).
        onDeviceChange = this.handleDeviceChange;
      }

      // in order to catch device changes prior to room connection we need to register the event in the constructor
      navigator.mediaDevices?.addEventListener?.('devicechange', onDeviceChange, {
        signal: cleanupController.signal,
      });
    }
  }

  /**
   * Installs resolved extensions on this room. `installExtensions()` in `extensions.ts` resolves
   * dependencies and calls this; `createRoom()` and the full `Room` go through it.
   * @internal
   */
  installExtensions(extensions: readonly RoomExtension<any, any>[]) {
    const ctx: ExtensionContext = {
      log: this.log,
      get: (ext) => {
        const result = this.installedExtensions.get(ext.key);
        if (!result) {
          // @throws-transformer ignore - programmer error
          throw new Error(`extension '${String(ext.key)}' is not installed`);
        }
        return result as any;
      },
      slot: (slot) => this.slots[slot],
      getOrCreateParticipant: (identity, info) => this.getOrCreateParticipant(identity, info),
      simulateConnected: (roomInfo, localParticipantInfo) =>
        this.simulateConnected(roomInfo, localParticipantInfo),
      acquireEmptyAudioStreamTrack: () => this.acquireEmptyAudioStreamTrack(),
    };
    const results: ExtensionResult<any, any>[] = [];
    for (const ext of extensions) {
      if (this.installedExtensions.has(ext.key)) {
        // @throws-transformer ignore - programmer error
        throw new Error(`extension '${String(ext.key)}' is already installed`);
      }
      const result = ext.install(this, ctx);
      this.installedExtensions.set(ext.key, result);
      results.push(result);
      for (const [kind, handler] of Object.entries(result.dataPackets ?? {})) {
        if (this.dataPacketHandlers.has(kind as DataPacketCase)) {
          // @throws-transformer ignore - programmer error
          throw new Error(`data packet case '${kind}' is already handled by another extension`);
        }
        this.dataPacketHandlers.set(kind as DataPacketCase, (packet, encryptionType, participant) =>
          (handler as any)(packet.value.value, packet, encryptionType, participant),
        );
      }
      for (const key of SLOT_KEYS) {
        if (result[key] !== undefined) {
          (this.slots as Record<string, unknown>)[key] = result[key];
        }
      }
      defineExtensionApi(this, CoreRoom.prototype, result.room, ext);
      defineExtensionApi(
        this.localParticipant,
        LocalParticipant.prototype,
        result.localParticipant,
        ext,
      );
      if (result.dispose) {
        this.extensionDisposers.push(result.dispose);
      }
    }
    this.applySlotsToEngine();
    // every slot of the list is filled before the first hook runs
    results.forEach((result) => result.onEngineCreated?.(this.engine));
  }

  /** The engine keeps its own copy of the slots it reads on the hot path. */
  private applySlotsToEngine() {
    this.engine.e2eeManager = this.slots.e2eeManager;
    this.engine.frameMetadataOptions = this.slots.frameMetadataOptions;
  }

  private get extensionResults() {
    return Array.from(this.installedExtensions.values());
  }

  /**
   * Releases everything the room holds: disconnects if connected, disposes the extensions and
   * removes global listeners. The room cannot connect again afterwards.
   */
  async dispose() {
    if (this.disposed) {
      return;
    }
    this.disposed = true;
    if (this.state !== ConnectionState.Disconnected) {
      await this.disconnect();
    }
    for (const dispose of this.extensionDisposers.reverse()) {
      dispose();
    }
    this.cleanupController?.abort();
  }

  private get logContext() {
    return {
      room: this.name,
      roomID: this.roomInfo?.sid,
      participant: this.localParticipant?.identity,
      participantID: this.localParticipant?.sid,
    };
  }

  /**
   * if the current room has a participant with `recorder: true` in its JWT grant
   **/
  get isRecording(): boolean {
    return this.roomInfo?.activeRecording ?? false;
  }

  /**
   * server assigned unique room id.
   * returns once a sid has been issued by the server.
   */
  getSid(): TypedPromise<string, UnexpectedConnectionState> {
    if (this.state === ConnectionState.Disconnected) {
      return TypedPromise.resolve('');
    }
    if (this.roomInfo && this.roomInfo.sid !== '') {
      return TypedPromise.resolve(this.roomInfo.sid);
    }
    return new TypedPromise<string, UnexpectedConnectionState>((resolve, reject) => {
      const handleRoomUpdate = (roomInfo: RoomModel) => {
        if (roomInfo.sid !== '') {
          this.engine.off(EngineEvent.RoomUpdate, handleRoomUpdate);
          resolve(roomInfo.sid);
        }
      };
      this.engine.on(EngineEvent.RoomUpdate, handleRoomUpdate);
      this.once(RoomEvent.Disconnected, () => {
        this.engine.off(EngineEvent.RoomUpdate, handleRoomUpdate);
        reject(
          new UnexpectedConnectionState('Room disconnected before room server id was available'),
        );
      });
    });
  }

  /** user assigned name, derived from JWT token */
  get name(): string {
    return this.roomInfo?.name ?? '';
  }

  /** room metadata */
  get metadata(): string | undefined {
    return this.roomInfo?.metadata;
  }

  get numParticipants(): number {
    return this.roomInfo?.numParticipants ?? 0;
  }

  get numPublishers(): number {
    return this.roomInfo?.numPublishers ?? 0;
  }

  private maybeCreateEngine() {
    if (this.engine && (this.engine.isNewlyCreated || !this.engine.isClosed)) {
      return;
    }

    this.engine = new RTCEngine(this.options);
    this.applySlotsToEngine();

    this.engine
      .on(EngineEvent.ParticipantUpdate, this.handleParticipantUpdates)
      .on(EngineEvent.RoomUpdate, this.handleRoomUpdate)
      .on(EngineEvent.SpeakersChanged, this.handleSpeakersChanged)
      .on(EngineEvent.StreamStateChanged, this.handleStreamStateUpdate)
      .on(EngineEvent.ConnectionQualityUpdate, this.handleConnectionQualityUpdate)
      .on(EngineEvent.SubscriptionError, this.handleSubscriptionError)
      .on(EngineEvent.SubscriptionPermissionUpdate, this.handleSubscriptionPermissionUpdate)
      .on(
        EngineEvent.MediaTrackAdded,
        (mediaTrack: MediaStreamTrack, stream: MediaStream, receiver: RTCRtpReceiver) => {
          this.onTrackAdded(mediaTrack, stream, receiver);
        },
      )
      .on(EngineEvent.Disconnected, (reason?: DisconnectReason) => {
        // the server can end the session while connect() still waits for the transports (e.g. a
        // DUPLICATE_IDENTITY leave). Cancel that attempt: left running, it times out, fails over to
        // another region and rejoins with the same token after the room reported Disconnected,
        // and disconnect() can't stop it since the room already looks disconnected
        this.abortController?.abort('room disconnected by the server during connection attempt');
        this.handleDisconnect(this.options.stopLocalTrackOnUnpublish, reason);
      })
      .on(EngineEvent.ActiveSpeakersUpdate, this.handleActiveSpeakersUpdate)
      .on(EngineEvent.DataPacketReceived, this.handleDataPacket)
      .on(EngineEvent.Resuming, () => {
        this.clearConnectionReconcile();
        this.isResuming = true;
        this.log.debug('Resuming signal connection');
        // During connect(), the room stays `Connecting` and connect() reports the outcome.
        if (
          !this.connectFuture &&
          this.setAndEmitConnectionState(ConnectionState.SignalReconnecting)
        ) {
          this.emit(RoomEvent.SignalReconnecting);
        }
      })
      .on(EngineEvent.Resumed, () => {
        this.registerConnectionReconcile();
        this.isResuming = false;
        this.log.debug('Resumed signal connection');
        this.updateSubscriptions();
        if (this.connectFuture) {
          // connect() emits `Connected`; as on any initial join, events from before it are dropped.
          this.bufferedEvents = [];
          return;
        }
        if (this.setAndEmitConnectionState(ConnectionState.Connected)) {
          this.emit(RoomEvent.Reconnected);
        }
        this.emitBufferedEvents();
      })
      .on(EngineEvent.SignalResumed, () => {
        if (this.state === ConnectionState.Reconnecting || this.isResuming) {
          this.sendSyncState();
        }
        this.emitBufferedEvents();
      })
      .on(EngineEvent.Restarting, this.handleRestarting)
      .on(EngineEvent.SignalRestarted, this.handleSignalRestarted)
      .on(EngineEvent.Restarted, () => {
        // normally handleSignalRestarted flushes after the restart, but if the room already
        // reports connected, anything buffered since then would otherwise wait for the next reconnect
        if (this.state === ConnectionState.Connected) {
          this.emitBufferedEvents();
        }
      })
      .on(EngineEvent.Offline, () => {
        // During connect(), the room stays `Connecting` and connect() reports the outcome.
        if (!this.connectFuture && this.setAndEmitConnectionState(ConnectionState.Reconnecting)) {
          this.emit(RoomEvent.Reconnecting);
        }
      })
      .on(EngineEvent.DCBufferStatusChanged, (status, kind) => {
        this.emit(RoomEvent.DCBufferStatusChanged, status, kind);
      })
      .on(EngineEvent.LocalTrackSubscribed, (subscribedSid) => {
        this.handleLocalTrackSubscribed(subscribedSid);
      })
      .on(EngineEvent.RoomMoved, (roomMoved) => {
        this.log.debug('room moved', roomMoved);

        if (roomMoved.room) {
          this.handleRoomUpdate(roomMoved.room);
        }

        this.remoteParticipants.forEach((participant, identity) => {
          this.handleParticipantDisconnected(identity, participant);
        });

        this.emit(RoomEvent.Moved, roomMoved.room!.name);

        if (roomMoved.participant) {
          this.handleParticipantUpdates([roomMoved.participant, ...roomMoved.otherParticipants]);
        } else {
          this.handleParticipantUpdates(roomMoved.otherParticipants);
        }
      })
      .on(EngineEvent.TokenRefreshed, (token) => {
        this.regionUrlProvider?.updateToken(token);
      })
      .on(EngineEvent.ServerRegionsReported, (regions) => {
        this.regionUrlProvider?.setServerReportedRegions({
          regionSettings: regions,
          updatedAtInMs: Date.now(),
          maxAgeInMs: DEFAULT_MAX_AGE_MS,
        });
      })
      .on(EngineEvent.RequestSubscribedCodecRefresh, () => {
        for (const videoPub of this.localParticipant.videoTrackPublications.values()) {
          if (isLocalVideoTrack(videoPub.track)) {
            videoPub.track.refreshSubscribedCodecs();
          }
        }
      });

    if (this.localParticipant) {
      this.localParticipant.setupEngine(this.engine);
    }
    if (this.slots.e2eeManager) {
      this.slots.e2eeManager.setupEngine(this.engine);
    }
    this.extensionResults.forEach((result) => result.onEngineCreated?.(this.engine));
  }

  private createRegionStrategy(): RegionStrategy {
    return {
      getNextUrl: async (signal?: AbortSignal) =>
        this.regionUrlProvider ? this.regionUrlProvider.getNextBestRegionUrl(signal) : null,
      resetAttempts: () => this.regionUrlProvider?.resetAttempts(),
    };
  }

  /**
   * getLocalDevices abstracts navigator.mediaDevices.enumerateDevices.
   * In particular, it requests device permissions by default if needed
   * and makes sure the returned device does not consist of dummy devices
   * @param kind
   * @returns a list of available local devices
   */
  static getLocalDevices(
    kind?: MediaDeviceKind,
    requestPermissions: boolean = true,
  ): Promise<MediaDeviceInfo[]> {
    return DeviceManager.getInstance().getDevices(kind, requestPermissions);
  }

  static cleanupRegistry =
    typeof FinalizationRegistry !== 'undefined' &&
    typeof WeakRef !== 'undefined' &&
    new FinalizationRegistry((cleanupController: AbortController) => {
      cleanupController.abort();
    });

  /**
   * Builds the constructor's `devicechange` listener. It lives outside the constructor so that
   * its closure only captures `roomRef`, not the constructor's context (which holds the Room).
   */
  private static createWeakDeviceChangeListener(roomRef: WeakRef<CoreRoom>) {
    return () => {
      roomRef.deref()?.handleDeviceChange();
    };
  }

  /**
   * prepareConnection should be called as soon as the page is loaded, in order
   * to speed up the connection attempt. This function will
   * - perform DNS resolution and pre-warm the DNS cache
   * - establish TLS connection and cache TLS keys
   *
   * With LiveKit Cloud, it will also determine the best edge data center for
   * the current client to connect to if a token is provided.
   */
  async prepareConnection(url: string, token?: string) {
    if (this.state !== ConnectionState.Disconnected) {
      return;
    }
    this.log.debug(`prepareConnection to ${url}`);
    try {
      if (isCloud(new URL(url)) && token) {
        this.regionUrlProvider = new RegionUrlProvider(url, token);
        const regionUrl = await this.regionUrlProvider.getNextBestRegionUrl();
        // we will not replace the regionUrl if an attempt had already started
        // to avoid overriding regionUrl after a new connection attempt had started
        if (regionUrl && this.state === ConnectionState.Disconnected) {
          this.regionUrl = regionUrl;
          await fetch(toHttpUrl(regionUrl), { method: 'HEAD' });
          this.log.debug(`prepared connection to ${regionUrl}`);
        }
      } else {
        await fetch(toHttpUrl(url), { method: 'HEAD' });
      }
    } catch (e) {
      this.log.warn('could not prepare connection', { error: e });
    }
  }

  connect = async (url: string, token: string, opts?: RoomConnectOptions): Promise<void> => {
    if (this.disposed) {
      throw new UnexpectedConnectionState('room has been disposed');
    }
    if (!isBrowserSupported()) {
      if (isReactNative()) {
        throw Error("WebRTC isn't detected, have you called registerGlobals?");
      } else {
        throw Error(
          "LiveKit doesn't seem to be supported on this browser. Try to update your browser and make sure no browser extensions are disabling webRTC.",
        );
      }
    }

    // In case a disconnect called happened right before the connect call, make sure the disconnect is completed first by awaiting its lock
    const unlockDisconnect = await this.disconnectLock.lock();

    if (this.disposed) {
      // dispose() ran while this call waited for a disconnect to finish
      unlockDisconnect();
      throw new UnexpectedConnectionState('room has been disposed');
    }

    if (this.state === ConnectionState.Connected) {
      // when the state is reconnecting or connected, this function returns immediately
      this.log.info(`already connected to room ${this.name}`);
      unlockDisconnect();
      return Promise.resolve();
    }

    if (this.connectFuture) {
      unlockDisconnect();
      return this.connectFuture.promise;
    }

    this.setAndEmitConnectionState(ConnectionState.Connecting);
    if (this.regionUrlProvider?.getServerUrl().toString() !== ensureTrailingSlash(url)) {
      this.regionUrl = undefined;
      this.regionUrlProvider = undefined;
    }
    if (isCloud(new URL(url))) {
      if (this.regionUrlProvider === undefined) {
        this.regionUrlProvider = new RegionUrlProvider(url, token);
      } else {
        this.regionUrlProvider.updateToken(token);
      }
      // trigger the first fetch without waiting for a response
      // if initial connection fails, this will speed up picking regional url
      // on subsequent runs
      this.regionUrlProvider
        .fetchRegionSettings()
        .then((settings) => {
          this.regionUrlProvider?.setServerReportedRegions(settings);
        })
        .catch((e) => {
          this.log.warn('could not fetch region settings', { error: e });
        });
    }

    const connectFn = async (
      resolve: () => void,
      reject: (reason: any) => void,
      regionUrl?: string,
    ) => {
      if (this.abortController) {
        this.abortController.abort();
      }

      // explicit creation as local var needed to satisfy TS compiler when passing it to `attemptConnection` further down
      const abortController = new AbortController();
      this.abortController = abortController;

      // at this point the intention to connect has been signalled so we can allow cancelling of the connection via disconnect() again
      unlockDisconnect?.();

      const failAttempt = (error: unknown, reason?: DisconnectReason) => {
        // once a newer connect() replaced this attempt's controller, the room's state belongs to it
        if (this.abortController === abortController) {
          this.handleDisconnect(this.options.stopLocalTrackOnUnpublish, reason);
        }
        reject(error);
      };

      try {
        await BackOffStrategy.getInstance().getBackOffPromise(url);
        if (abortController.signal.aborted) {
          throw ConnectionError.cancelled('Connection attempt aborted');
        }
        await this.attemptConnection(regionUrl ?? url, token, opts, abortController);
        this.abortController = undefined;
        resolve();
      } catch (error) {
        if (
          this.regionUrlProvider &&
          error instanceof ConnectionError &&
          canFailOverToAnotherRegion(error)
        ) {
          let nextUrl: string | null = null;
          try {
            this.log.debug('Fetching next region');
            nextUrl = await this.regionUrlProvider.getNextBestRegionUrl(abortController.signal);
          } catch (regionFetchError) {
            if (
              regionFetchError instanceof ConnectionError &&
              (regionFetchError.status === 401 ||
                regionFetchError.reason === ConnectionErrorReason.Cancelled)
            ) {
              failAttempt(regionFetchError);
              return;
            }
          }
          if (
            // making sure we only register failed attempts on things we actually care about
            [
              ConnectionErrorReason.InternalError,
              ConnectionErrorReason.ServerUnreachable,
              ConnectionErrorReason.Timeout,
            ].includes(error.reason)
          ) {
            this.log.debug('Adding failed connection attempt to back off');
            BackOffStrategy.getInstance().addFailedConnectionAttempt(url);
          }
          if (nextUrl && !abortController.signal.aborted) {
            this.log.info(
              `Initial connection failed with ConnectionError: ${error.message}. Retrying with another region: ${nextUrl}`,
            );
            this.recreateEngine(true);
            await connectFn(resolve, reject, nextUrl);
          } else {
            failAttempt(error, getDisconnectReasonFromConnectionError(error));
          }
        } else {
          let disconnectReason = DisconnectReason.UNKNOWN_REASON;
          if (error instanceof ConnectionError) {
            disconnectReason = getDisconnectReasonFromConnectionError(error);
          }
          failAttempt(error, disconnectReason);
        }
      }
    };

    const regionUrl = this.regionUrl;
    this.regionUrl = undefined;
    this.connectFuture = new Future(
      (resolve, reject) => {
        connectFn(resolve, reject, regionUrl);
      },
      () => {
        this.clearConnectionFutures();
      },
    );

    return this.connectFuture.promise;
  };

  private connectSignal = async (
    url: string,
    token: string,
    engine: RTCEngine,
    connectOptions: InternalRoomConnectOptions,
    roomOptions: InternalRoomOptions,
    abortController: AbortController,
  ): Promise<JoinResponse> => {
    const { joinResponse, serverInfo } = await engine.join(
      url,
      token,
      {
        autoSubscribe: connectOptions.autoSubscribe,
        adaptiveStream:
          typeof roomOptions.adaptiveStream === 'object' ? true : roomOptions.adaptiveStream,
        disableIceLite: connectOptions.disableIceLite,
        subscriberAllowPause: connectOptions.subscriberAllowPause,
        clientInfoCapabilities: this.getClientInfoCapabilities(),
        maxRetries: connectOptions.maxRetries,
        e2eeEnabled: !!this.slots.e2eeManager,
        websocketTimeout: connectOptions.websocketTimeout,
      },
      abortController.signal,
      !roomOptions.singlePeerConnection,
    );

    this.serverInfo = serverInfo;

    if (!serverInfo.version) {
      throw new UnsupportedServer('unknown server version');
    }

    if (serverInfo.version === '0.15.1' && this.options.dynacast) {
      this.log.debug('disabling dynacast due to server version');
      // dynacast has a bug in 0.15.1, so we cannot use it then
      roomOptions.dynacast = false;
    }

    return joinResponse;
  };

  private applyJoinResponse = (joinResponse: JoinResponse) => {
    const pi = joinResponse.participant!;

    this.localParticipant.sid = pi.sid;
    this.localParticipant.identity = pi.identity;
    this.localParticipant.setEnabledPublishCodecs(joinResponse.enabledPublishCodecs);

    if (this.slots.e2eeManager) {
      try {
        this.slots.e2eeManager.setSifTrailer(joinResponse.sifTrailer as NonSharedUint8Array);
      } catch (e: any) {
        this.log.error(e instanceof Error ? e.message : 'Could not set SifTrailer', {
          error: e,
        });
      }
    }

    // populate remote participants, these should not trigger new events
    this.handleParticipantUpdates([pi, ...joinResponse.otherParticipants]);

    if (joinResponse.room) {
      this.handleRoomUpdate(joinResponse.room);
    }
  };

  private attemptConnection = async (
    url: string,
    token: string,
    opts: RoomConnectOptions | undefined,
    abortController: AbortController,
  ) => {
    if (
      this.state === ConnectionState.Reconnecting ||
      this.isResuming ||
      this.engine?.pendingReconnect
    ) {
      this.log.info('Reconnection attempt replaced by new connection attempt');
      // make sure we close and recreate the existing engine in order to get rid of any potentially ongoing reconnection attempts
      this.recreateEngine(true);
    } else {
      // create engine if previously disconnected
      this.maybeCreateEngine();
    }
    // a concurrent disconnect() or connect() can replace or clear `this.engine` while we await below
    const engine = this.engine;
    if (this.regionUrlProvider?.isCloud()) {
      engine.setRegionStrategy(this.createRegionStrategy());
    }

    this.acquireAudioContext(true).catch((error) =>
      this.log.warn('Could not acquire audio context', { ...this.logContext, error }),
    );

    this.connOptions = { ...roomConnectOptionDefaults, ...opts } as InternalRoomConnectOptions;

    if (this.connOptions.rtcConfig) {
      engine.rtcConfig = this.connOptions.rtcConfig;
    }
    if (this.connOptions.peerConnectionTimeout) {
      engine.peerConnectionTimeout = this.connOptions.peerConnectionTimeout;
    }

    try {
      const joinResponse = await this.connectSignal(
        url,
        token,
        engine,
        this.connOptions,
        this.options,
        abortController,
      );

      this.applyJoinResponse(joinResponse);
      // forward metadata changed for the local participant
      this.setupLocalParticipantEvents();
      this.emit(RoomEvent.SignalConnected);
    } catch (err) {
      await engine.close();
      this.recreateEngine(false, engine);

      const resultingError = abortController.signal.aborted
        ? ConnectionError.cancelled('Signal connection aborted')
        : ConnectionError.serverUnreachable('could not establish signal connection');

      if (err instanceof Error) {
        resultingError.message = `${resultingError.message}: ${err.message}`;
      }
      if (err instanceof ConnectionError) {
        resultingError.reason = err.reason;
        resultingError.status = err.status;
      }
      this.log.debug(`error trying to establish signal connection`, {
        error: err,
      });
      throw resultingError;
    }

    if (abortController.signal.aborted) {
      await engine.close();
      this.recreateEngine(false, engine);
      throw ConnectionError.cancelled(`Connection attempt aborted`);
    }

    try {
      await engine.waitForPCInitialConnection(
        this.connOptions.peerConnectionTimeout,
        abortController,
      );
    } catch (e) {
      await engine.close();
      this.recreateEngine(false, engine);
      throw e;
    }

    // also hook unload event
    if (isWeb() && this.options.disconnectOnPageLeave) {
      // capturing both 'pagehide' and 'beforeunload' to capture broadest set of browser behaviors
      window.addEventListener('pagehide', this.onPageLeave);
      window.addEventListener('beforeunload', this.onPageLeave);
    }
    if (isWeb()) {
      window.addEventListener('freeze', this.onPageLeave);
    }
    this.setAndEmitConnectionState(ConnectionState.Connected);
    this.emit(RoomEvent.Connected);
    BackOffStrategy.getInstance().resetFailedConnectionAttempts(url);
    this.registerConnectionReconcile();

    // Notify region provider about successful connection
    if (this.regionUrlProvider) {
      this.regionUrlProvider.notifyConnected();
    }
  };

  /**
   * disconnects the room, emits [[RoomEvent.Disconnected]]
   */
  disconnect = async (stopTracks = true) => {
    const unlock = await this.disconnectLock.lock();
    try {
      if (this.state === ConnectionState.Disconnected) {
        this.log.debug('already disconnected');
        return;
      }
      this.log.info('disconnect from room');
      if (
        this.state === ConnectionState.Connecting ||
        this.state === ConnectionState.Reconnecting ||
        this.isResuming
      ) {
        // try aborting pending connection attempt
        const msg = 'Abort connection attempt due to user initiated disconnect';
        this.log.warn(msg);
        this.abortController?.abort(msg);
        // in case the abort controller didn't manage to cancel the connection attempt, reject the connect promise explicitly
        this.connectFuture?.reject?.(ConnectionError.cancelled('Client initiated disconnect'));
        this.connectFuture = undefined;
      }

      // close engine (also closes client)
      if (this.engine) {
        // send leave
        if (!this.engine.client.isDisconnected) {
          await this.engine.client.sendLeave();
        }
        await this.engine.close();
      }
      this.handleDisconnect(stopTracks, DisconnectReason.CLIENT_INITIATED);
      /* @ts-ignore */
      this.engine = undefined;
    } finally {
      unlock();
    }
  };

  /**
   * retrieves a participant by identity
   * @param identity
   * @returns
   */
  getParticipantByIdentity(identity: string): Participant | undefined {
    if (this.localParticipant.identity === identity) {
      return this.localParticipant;
    }
    return this.remoteParticipants.get(identity);
  }

  private clearConnectionFutures() {
    this.connectFuture = undefined;
  }

  /**
   * @internal for testing
   */
  async simulateScenario(scenario: SimulationScenario, arg?: any) {
    let postAction = async () => {};
    let req: SimulateScenario | undefined;
    switch (scenario) {
      case 'signal-reconnect':
        const reconnectDelay = typeof arg === 'number' ? arg : 0;
        // @ts-expect-error function is private
        await this.engine.client.handleOnClose('simulate disconnect', undefined, reconnectDelay);
        break;
      case 'fail-on-v1-path':
        this.engine.failNextV1Path();
        break;
      case 'speaker':
        req = new SimulateScenario({
          scenario: {
            case: 'speakerUpdate',
            value: 3,
          },
        });
        break;
      case 'node-failure':
        req = new SimulateScenario({
          scenario: {
            case: 'nodeFailure',
            value: true,
          },
        });
        break;
      case 'server-leave':
        req = new SimulateScenario({
          scenario: {
            case: 'serverLeave',
            value: true,
          },
        });
        break;
      case 'migration':
        req = new SimulateScenario({
          scenario: {
            case: 'migration',
            value: true,
          },
        });
        break;
      case 'resume-reconnect':
        this.engine.failNext();
        // @ts-expect-error function is private
        await this.engine.client.handleOnClose('simulate resume-disconnect');
        break;
      case 'disconnect-signal-on-resume':
        postAction = async () => {
          // @ts-expect-error function is private
          await this.engine.client.handleOnClose('simulate resume-disconnect');
        };
        req = new SimulateScenario({
          scenario: {
            case: 'disconnectSignalOnResume',
            value: true,
          },
        });
        break;
      case 'disconnect-signal-on-resume-no-messages':
        postAction = async () => {
          // @ts-expect-error function is private
          await this.engine.client.handleOnClose('simulate resume-disconnect');
        };
        req = new SimulateScenario({
          scenario: {
            case: 'disconnectSignalOnResumeNoMessages',
            value: true,
          },
        });
        break;
      case 'full-reconnect':
        this.engine.fullReconnectOnNext = true;
        // @ts-expect-error function is private
        await this.engine.client.handleOnClose('simulate full-reconnect');
        break;
      case 'force-tcp':
      case 'force-tls':
        req = new SimulateScenario({
          scenario: {
            case: 'switchCandidateProtocol',
            value: scenario === 'force-tls' ? 2 : 1,
          },
        });
        postAction = async () => {
          const onLeave = this.engine.client.onLeave;
          if (onLeave) {
            onLeave(
              new LeaveRequest({
                reason: DisconnectReason.CLIENT_INITIATED,
                action: LeaveRequest_Action.RECONNECT,
              }),
            );
          }
        };
        break;
      case 'subscriber-bandwidth':
        if (arg === undefined || typeof arg !== 'number') {
          throw new Error('subscriber-bandwidth requires a number as argument');
        }
        req = new SimulateScenario({
          scenario: {
            case: 'subscriberBandwidth',
            value: numberToBigInt(arg),
          },
        });
        break;
      case 'leave-full-reconnect':
        req = new SimulateScenario({
          scenario: {
            case: 'leaveRequestFullReconnect',
            value: true,
          },
        });
      default:
    }
    if (req) {
      await this.engine.client.sendSimulateScenario(req);
      await postAction();
    }
  }

  private onPageLeave = async () => {
    this.log.info('Page leave detected, disconnecting');
    await this.disconnect();
  };

  /**
   * iOS blocks audio element playback if
   * - user is not publishing audio themselves and
   * - no other audio source is playing
   *
   * as a workaround, we create an audio element with an empty track, so that
   * silent audio is always playing
   *
   * The element is shared with any other room on the page and handed back on disconnect, so it
   * outlives whichever room happened to create it.
   */
  private acquireDummyAudioElement(): HTMLAudioElement {
    if (!sharedDummyAudioElement) {
      sharedDummyAudioElement = createSharedDummyAudioElement();
    }
    const shared = sharedDummyAudioElement;
    if (this.releaseDummyAudioElement) {
      // this room already holds a reference, a second one would never be handed back
      return shared.element;
    }
    shared.refCount += 1;

    // the listener is per room rather than shared, so that the room it resumes playback for is
    // still connected, and so that it goes away with the room that installed it
    const handleVisibilityChange = () => {
      // set the srcObject to null on page hide in order to prevent lock screen controls to show up for it
      shared.element.srcObject = document.hidden ? null : shared.stream;
      if (!document.hidden) {
        this.log.debug(
          'page visible again, triggering startAudio to resume playback and update playback status',
        );
        this.startAudio().catch((error) =>
          this.log.warn('Could not restart audio on page becoming visible', {
            ...this.logContext,
            error,
          }),
        );
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    this.releaseDummyAudioElement = () => {
      this.releaseDummyAudioElement = undefined;
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      shared.refCount -= 1;
      if (shared.refCount > 0) {
        return;
      }
      shared.element.srcObject = null;
      shared.element.remove();
      sharedDummyAudioElement = undefined;
      releaseEmptyAudioStreamTrack(shared.track).catch((error) =>
        this.log.warn('Could not release the dummy audio element track', {
          ...this.logContext,
          error,
        }),
      );
    };

    return shared.element;
  }

  /**
   * Obtains a silent audio track from the shared source and keeps track of it, so that it can be
   * handed back on disconnect and the shared `AudioContext` behind it can be closed again.
   */
  private acquireEmptyAudioStreamTrack(): MediaStreamTrack {
    const track = getEmptyAudioStreamTrack();
    this.acquiredEmptyAudioTracks.add(track);
    return track;
  }

  private releaseAcquiredEmptyAudioTrack(track: MediaStreamTrack) {
    if (!this.acquiredEmptyAudioTracks.delete(track)) {
      return;
    }
    releaseEmptyAudioStreamTrack(track).catch((error) =>
      this.log.warn('Could not release empty audio stream track', { ...this.logContext, error }),
    );
  }

  private releaseAcquiredEmptyAudioTracks() {
    for (const track of this.acquiredEmptyAudioTracks) {
      this.releaseAcquiredEmptyAudioTrack(track);
    }
  }

  /**
   * Browsers have different policies regarding audio playback. Most requiring
   * some form of user interaction (click/tap/etc).
   * In those cases, audio will be silent until a click/tap triggering one of the following
   * - `startAudio`
   * - `getUserMedia`
   */
  startAudio = async () => {
    const elements: Array<HTMLMediaElement> = [];
    const browser = getBrowser();
    if (browser && browser.os === 'iOS' && !this.audioContextReleased) {
      elements.push(this.acquireDummyAudioElement());
    }

    this.remoteParticipants.forEach((p) => {
      p.audioTrackPublications.forEach((t) => {
        if (t.track) {
          t.track.attachedElements.forEach((e) => {
            elements.push(e);
          });
        }
      });
    });

    try {
      await Promise.all([
        // once the audio context has been released as part of a disconnect there is nothing left
        // to unlock, and creating a new context here would leak it as no disconnect will follow
        ...(this.audioContextReleased ? [] : [this.acquireAudioContext()]),
        ...elements.map((e) => {
          // when webAudioMix is enabled, attached elements are deliberately kept muted by
          // RemoteAudioTrack.attach() and audio is routed through the web audio graph instead.
          // unmuting them here would cause double playback on platforms where element.volume
          // has no effect (e.g. iOS Safari)
          if (!this.options.webAudioMix) {
            e.muted = false;
          }
          return e.play();
        }),
      ]);
      this.handleAudioPlaybackStarted();
    } catch (err) {
      this.handleAudioPlaybackFailed(err);
      throw err;
    }
  };

  startVideo = async () => {
    const elements: HTMLMediaElement[] = [];
    for (const p of this.remoteParticipants.values()) {
      p.videoTrackPublications.forEach((tr) => {
        tr.track?.attachedElements.forEach((el) => {
          if (!elements.includes(el)) {
            elements.push(el);
          }
        });
      });
    }
    await Promise.all(elements.map((el) => el.play()))
      .then(() => {
        this.handleVideoPlaybackStarted();
      })
      .catch((e) => {
        if (e.name === 'NotAllowedError') {
          this.handleVideoPlaybackFailed();
        } else {
          this.log.warn(
            'Resuming video playback failed, make sure you call `startVideo` directly in a user gesture handler',
          );
        }
      });
  };

  /**
   * Returns true if audio playback is enabled
   */
  get canPlaybackAudio(): boolean {
    return this.audioEnabled;
  }

  /**
   * Returns true if video playback is enabled
   */
  get canPlaybackVideo(): boolean {
    return !this.isVideoPlaybackBlocked;
  }

  getActiveDevice(kind: MediaDeviceKind): string | undefined {
    return this.localParticipant.activeDeviceMap.get(kind);
  }

  /**
   * Switches all active devices used in this room to the given device.
   *
   * Note: setting AudioOutput is not supported on some browsers. See [setSinkId](https://developer.mozilla.org/en-US/docs/Web/API/HTMLMediaElement/setSinkId#browser_compatibility)
   *
   * @param kind use `videoinput` for camera track,
   *  `audioinput` for microphone track,
   *  `audiooutput` to set speaker for all incoming audio tracks
   * @param deviceId
   */
  async switchActiveDevice(kind: MediaDeviceKind, deviceId: string, exact: boolean = true) {
    let success = true;
    let shouldTriggerImmediateDeviceChange = false;
    const deviceConstraint = exact ? { exact: deviceId } : deviceId;
    if (kind === 'audioinput') {
      shouldTriggerImmediateDeviceChange = this.localParticipant.audioTrackPublications.size === 0;
      const prevDeviceId =
        this.getActiveDevice(kind) ?? this.options.audioCaptureDefaults!.deviceId;
      this.options.audioCaptureDefaults!.deviceId = deviceConstraint;
      const tracks = Array.from(this.localParticipant.audioTrackPublications.values()).filter(
        (track) => track.source === Track.Source.Microphone,
      );
      try {
        success = (
          await Promise.all(tracks.map((t) => t.audioTrack?.setDeviceId(deviceConstraint)))
        ).every((val) => val === true);
      } catch (e) {
        this.options.audioCaptureDefaults!.deviceId = prevDeviceId;
        throw e;
      }
      const isMuted = tracks.some((t) => t.track?.isMuted ?? false);
      if (success && isMuted) shouldTriggerImmediateDeviceChange = true;
    } else if (kind === 'videoinput') {
      shouldTriggerImmediateDeviceChange = this.localParticipant.videoTrackPublications.size === 0;
      const prevDeviceId =
        this.getActiveDevice(kind) ?? this.options.videoCaptureDefaults!.deviceId;
      this.options.videoCaptureDefaults!.deviceId = deviceConstraint;
      const tracks = Array.from(this.localParticipant.videoTrackPublications.values()).filter(
        (track) => track.source === Track.Source.Camera,
      );
      try {
        success = (
          await Promise.all(tracks.map((t) => t.videoTrack?.setDeviceId(deviceConstraint)))
        ).every((val) => val === true);
      } catch (e) {
        this.options.videoCaptureDefaults!.deviceId = prevDeviceId;
        throw e;
      }
      const isMuted = tracks.some((t) => t.track?.isMuted ?? false);
      if (success && isMuted) shouldTriggerImmediateDeviceChange = true;
    } else if (kind === 'audiooutput') {
      shouldTriggerImmediateDeviceChange = true;
      if (
        (!supportsSetSinkId() && !this.options.webAudioMix) ||
        (this.options.webAudioMix && this.audioContext && !('setSinkId' in this.audioContext))
      ) {
        throw new Error('cannot switch audio output, the current browser does not support it');
      }
      if (this.options.webAudioMix) {
        // setting `default` for web audio output doesn't work, so we need to normalize the id before
        deviceId =
          (await DeviceManager.getInstance().normalizeDeviceId('audiooutput', deviceId)) ?? '';
      }
      this.options.audioOutput ??= {};
      const prevDeviceId = this.getActiveDevice(kind) ?? this.options.audioOutput.deviceId;
      this.options.audioOutput.deviceId = deviceId;

      try {
        if (this.options.webAudioMix) {
          // @ts-expect-error setSinkId is not yet in the typescript type of AudioContext
          this.audioContext?.setSinkId(deviceId);
        }

        // also set audio output on all audio elements, even if webAudioMix is enabled in order to workaround echo cancellation not working on chrome with non-default output devices
        // see https://issues.chromium.org/issues/40252911#comment7
        await Promise.all(
          Array.from(this.remoteParticipants.values()).map((p) => p.setAudioOutput({ deviceId })),
        );
      } catch (e) {
        this.options.audioOutput.deviceId = prevDeviceId;
        throw e;
      }
    }

    if (shouldTriggerImmediateDeviceChange) {
      this.localParticipant.activeDeviceMap.set(kind, deviceId);
      this.emit(RoomEvent.ActiveDeviceChanged, kind, deviceId);
    }

    return success;
  }

  private setupLocalParticipantEvents() {
    this.localParticipant
      .on(ParticipantEvent.ParticipantMetadataChanged, this.onLocalParticipantMetadataChanged)
      .on(ParticipantEvent.ParticipantNameChanged, this.onLocalParticipantNameChanged)
      .on(ParticipantEvent.AttributesChanged, this.onLocalAttributesChanged)
      .on(ParticipantEvent.TrackMuted, this.onLocalTrackMuted)
      .on(ParticipantEvent.TrackUnmuted, this.onLocalTrackUnmuted)
      .on(ParticipantEvent.LocalTrackPublished, this.onLocalTrackPublished)
      .on(ParticipantEvent.LocalTrackUnpublished, this.onLocalTrackUnpublished)
      .on(ParticipantEvent.ConnectionQualityChanged, this.onLocalConnectionQualityChanged)
      .on(ParticipantEvent.MediaDevicesError, this.onMediaDevicesError)
      .on(ParticipantEvent.AudioStreamAcquired, this.startAudio)
      .on(
        ParticipantEvent.ParticipantPermissionsChanged,
        this.onLocalParticipantPermissionsChanged,
      );
  }

  private recreateEngine(sendLeave?: boolean, oldEngine: RTCEngine | undefined = this.engine) {
    if (sendLeave && oldEngine && !oldEngine.client.isDisconnected) {
      oldEngine.client.sendLeave().finally(() => oldEngine.close());
    } else {
      oldEngine?.close();
    }
    // the room already moved on to a newer engine (or none); leave that one alone
    if (oldEngine !== this.engine) {
      return;
    }
    /* @ts-ignore */
    this.engine = undefined;
    this.isResuming = false;

    // clear out existing remote participants, since they may have attached
    // the old engine
    this.remoteParticipants.clear();
    this.sidToIdentity.clear();
    this.bufferedEvents = [];
    this.maybeCreateEngine();
  }

  private onTrackAdded(
    mediaTrack: MediaStreamTrack,
    stream: MediaStream,
    receiver: RTCRtpReceiver,
  ) {
    // don't fire onSubscribed when connecting
    // WebRTC fires onTrack as soon as setRemoteDescription is called on the offer
    // at that time, ICE connectivity has not been established so the track is not
    // technically subscribed.
    // We'll defer these events until when the room is connected or eventually disconnected.
    if ([ConnectionState.Connecting, ConnectionState.Reconnecting].includes(this.state)) {
      const pendingTrackSid = extractTrackSid(mediaTrack, stream);
      this.log.debug('deferring on track for later', {
        mediaTrackId: mediaTrack.id,
        mediaStreamId: stream.id,
        tracksInStream: stream.getTracks().map((track) => track.id),
      });
      const reconnectedHandler = () => {
        cleanup();
        this.onTrackAdded(mediaTrack, stream, receiver);
      };
      const cleanup = () => {
        this.off(RoomEvent.Reconnected, reconnectedHandler);
        this.off(RoomEvent.Connected, reconnectedHandler);
        this.off(RoomEvent.Disconnected, cleanup);
        if (pendingTrackSid) {
          const pendingCallbacks = this.pendingTrackAddedCallbacks.get(pendingTrackSid);
          pendingCallbacks?.delete(cleanup);
          if (pendingCallbacks?.size === 0) {
            this.pendingTrackAddedCallbacks.delete(pendingTrackSid);
          }
        }
      };
      this.once(RoomEvent.Reconnected, reconnectedHandler);
      this.once(RoomEvent.Connected, reconnectedHandler);
      this.once(RoomEvent.Disconnected, cleanup);
      if (pendingTrackSid) {
        const pendingCallbacks =
          this.pendingTrackAddedCallbacks.get(pendingTrackSid) ?? new Set<() => void>();
        pendingCallbacks.add(cleanup);
        this.pendingTrackAddedCallbacks.set(pendingTrackSid, pendingCallbacks);
      }
      return;
    }
    if (this.state === ConnectionState.Disconnected) {
      this.log.warn('skipping incoming track after Room disconnected');
      return;
    }
    if (mediaTrack.readyState === 'ended') {
      this.log.debug('skipping incoming track as it already ended');
      return;
    }
    const parts = unpackStreamId(stream.id);
    const participantSid = parts[0];
    const streamId = parts[1];
    // firefox will get streamId (pID|trackId) instead of (pID|streamId) as it doesn't support sync tracks by stream
    // and generates its own track id instead of infer from sdp track id.
    let trackId = extractTrackSid(mediaTrack, stream) ?? mediaTrack.id;

    if (participantSid === this.localParticipant.sid) {
      this.log.warn('tried to create RemoteParticipant for local participant');
      return;
    }

    const participant = Array.from(this.remoteParticipants.values()).find(
      (p) => p.sid === participantSid,
    ) as RemoteParticipant | undefined;

    if (!participant) {
      // server could require extra media sections to accelerate subscription.
      if (participantSid.startsWith('PA')) {
        this.log.error(
          `Tried to add a track for a participant, that's not present. Sid: ${participantSid}`,
        );
      }
      return;
    }

    // in single peer connection case, the trackID is locally generated,
    // not the TR_ prefixed one generated by the server,
    // use `mid` to find the appropriate track.
    if (!trackId.startsWith('TR')) {
      const id = this.engine.getTrackIdForReceiver(receiver);
      if (!id) {
        this.log.error(
          `Tried to add a track whose 'sid' could not be found for a participant, that's not present. Sid: ${participantSid}`,
        );
        return;
      }

      trackId = id;
    }
    if (!trackId.startsWith('TR')) {
      this.log.warn(
        `Tried to add a track whose 'sid' could not be determined for a participant, that's not present. Sid: ${participantSid}, streamId: ${streamId}, trackId: ${trackId}`,
        { remoteParticipantID: participantSid, streamId, trackId },
      );
    }

    let adaptiveStreamSettings: AdaptiveStreamSettings | undefined;
    if (this.options.adaptiveStream) {
      if (typeof this.options.adaptiveStream === 'object') {
        adaptiveStreamSettings = this.options.adaptiveStream;
      } else {
        adaptiveStreamSettings = {};
      }
    }

    const publication = participant.addSubscribedMediaTrack(
      mediaTrack,
      trackId,
      stream,
      receiver,
      adaptiveStreamSettings,
    );

    if (publication?.isEncrypted && !this.slots.e2eeManager) {
      this.emit(
        RoomEvent.EncryptionError,
        new Error(
          `Encrypted ${publication.source} track received from participant ${participant.sid}, but room does not have encryption enabled!`,
        ),
      );
    }
  }

  private cancelPendingTrackAdded(trackSid: Track.SID) {
    this.pendingTrackAddedCallbacks.get(trackSid)?.forEach((cleanup) => cleanup());
  }

  private handleLocalTrackSubscribed(subscribedSid: string) {
    const findPublication = () =>
      this.localParticipant
        .getTrackPublications()
        .find(({ trackSid }) => trackSid === subscribedSid) as LocalTrackPublication | undefined;

    const trackPublication = findPublication();
    if (trackPublication) {
      this.emitLocalTrackSubscribed(trackPublication);
      return;
    }

    // the track publication may not be registered yet if the server signals
    // the subscription before publishTrack has finished adding the publication.
    // defer with a timeout until LocalTrackPublished fires for the matching trackSid
    this.log.debug('deferring LocalTrackSubscribed, publication not yet available', {
      subscribedSid,
    });

    const TIMEOUT_MS = 10_000;
    let timer: ReturnType<typeof setTimeout>;

    const onPublished = (pub: LocalTrackPublication) => {
      if (pub.trackSid === subscribedSid) {
        cleanup();
        this.emitLocalTrackSubscribed(pub);
      }
    };

    const cleanup = () => {
      clearTimeout(timer);
      this.localParticipant.off(ParticipantEvent.LocalTrackPublished, onPublished);
      this.off(RoomEvent.Disconnected, cleanup);
    };

    this.localParticipant.on(ParticipantEvent.LocalTrackPublished, onPublished);
    this.once(RoomEvent.Disconnected, cleanup);

    timer = setTimeout(() => {
      cleanup();
      // final attempt in case the publication was added without emitting the event
      const pub = findPublication();
      if (pub) {
        this.emitLocalTrackSubscribed(pub);
      } else {
        this.log.warn(
          'could not find local track publication for LocalTrackSubscribed event after timeout',
          { subscribedSid },
        );
      }
    }, TIMEOUT_MS);
  }

  private emitLocalTrackSubscribed(trackPublication: LocalTrackPublication) {
    this.localParticipant.emit(ParticipantEvent.LocalTrackSubscribed, trackPublication);
    this.emitWhenConnected(RoomEvent.LocalTrackSubscribed, trackPublication, this.localParticipant);
  }

  private handleRestarting = () => {
    this.clearConnectionReconcile();
    // in case we went from resuming to full-reconnect, make sure to reflect it on the isResuming flag
    this.isResuming = false;

    // a region that failed after its join leaves its room state and held back events behind
    this.roomInfoBeforeRestart ??= this.roomInfo;
    this.roomInfo = this.roomInfoBeforeRestart;
    this.bufferedEvents = [];

    // also unwind existing participants & existing subscriptions
    for (const p of this.remoteParticipants.values()) {
      this.handleParticipantDisconnected(p.identity, p);
    }

    // During connect(), the room stays `Connecting` and connect() reports the outcome.
    if (!this.connectFuture && this.setAndEmitConnectionState(ConnectionState.Reconnecting)) {
      this.emit(RoomEvent.Reconnecting);
    }
  };

  private handleSignalRestarted = async (
    joinResponse: JoinResponse,
    restartAttempt: AbortSignal,
  ) => {
    this.log.debug(`signal reconnected to server, region ${joinResponse.serverRegion}`, {
      region: joinResponse.serverRegion,
    });
    this.bufferedEvents = [];
    const initialConnection = this.connectFuture !== undefined;
    const restarted = this.engine.waitForRestarted(restartAttempt);

    this.applyJoinResponse(joinResponse);

    try {
      // unpublish & republish tracks
      await this.localParticipant.republishAllTracks(undefined, true);
    } catch (error) {
      this.log.error('error trying to re-publish tracks after reconnection', { error });
    }

    // the attempt is aborted when a newer attempt began, on the next region or in a later
    // restart, or when the engine closed; whatever replaced it reports the outcome
    if (!(await restarted) || restartAttempt.aborted) {
      return;
    }
    this.log.debug(`fully reconnected to server`, { region: joinResponse.serverRegion });
    this.roomInfoBeforeRestart = undefined;
    if (initialConnection) {
      // connect() emits `Connected`; as on any initial join, events from before it are dropped.
      this.bufferedEvents = [];
      return;
    }
    this.setAndEmitConnectionState(ConnectionState.Connected);
    this.emit(RoomEvent.Reconnected);
    this.registerConnectionReconcile();
    this.emitBufferedEvents();
  };

  private handleDisconnect(shouldStopTracks = true, reason?: DisconnectReason) {
    this.clearConnectionReconcile();
    this.isResuming = false;
    this.bufferedEvents = [];
    this.roomInfoBeforeRestart = undefined;
    this.transcriptionReceivedTimes.clear();
    this.extensionResults.forEach((result) => result.onDisconnect?.());
    if (this.state === ConnectionState.Disconnected) {
      return;
    }

    this.regionUrl = undefined;

    // Notify region provider about disconnect to potentially stop auto-refetch
    if (this.regionUrlProvider) {
      this.regionUrlProvider.notifyDisconnected();
    }

    try {
      // audio tracks that outlive this room are about to become unreachable through the local
      // participant, collect them while we can so they can be detached from the context below
      const retainedAudioTracks = shouldStopTracks
        ? []
        : Array.from(this.localParticipant.audioTrackPublications.values())
            .map((pub) => pub.track)
            .filter(isLocalAudioTrack);

      this.remoteParticipants.forEach((p) => {
        p.trackPublications.forEach((pub) => {
          p.unpublishTrack(pub.trackSid);
        });
      });

      this.localParticipant.trackPublications.forEach((pub) => {
        if (pub.track) {
          this.localParticipant.unpublishTrack(pub.track, shouldStopTracks);
        }
        if (shouldStopTracks) {
          pub.track?.detach();
          pub.track?.stop();
        } else {
          pub.track?.stopMonitor();
        }
      });

      this.localParticipant
        .off(ParticipantEvent.ParticipantMetadataChanged, this.onLocalParticipantMetadataChanged)
        .off(ParticipantEvent.ParticipantNameChanged, this.onLocalParticipantNameChanged)
        .off(ParticipantEvent.AttributesChanged, this.onLocalAttributesChanged)
        .off(ParticipantEvent.TrackMuted, this.onLocalTrackMuted)
        .off(ParticipantEvent.TrackUnmuted, this.onLocalTrackUnmuted)
        .off(ParticipantEvent.LocalTrackPublished, this.onLocalTrackPublished)
        .off(ParticipantEvent.LocalTrackUnpublished, this.onLocalTrackUnpublished)
        .off(ParticipantEvent.ConnectionQualityChanged, this.onLocalConnectionQualityChanged)
        .off(ParticipantEvent.MediaDevicesError, this.onMediaDevicesError)
        .off(ParticipantEvent.AudioStreamAcquired, this.startAudio)
        .off(
          ParticipantEvent.ParticipantPermissionsChanged,
          this.onLocalParticipantPermissionsChanged,
        );

      this.localParticipant.trackPublications.clear();
      this.localParticipant.videoTrackPublications.clear();
      this.localParticipant.audioTrackPublications.clear();

      this.remoteParticipants.clear();
      this.sidToIdentity.clear();
      this.activeSpeakers = [];
      this.releaseDummyAudioElement?.();
      this.releaseAcquiredEmptyAudioTracks();
      // teardown is asynchronous (processors need to release their web audio nodes), but
      // `handleDisconnect` is not, so let it finish in the background
      this.releaseAudioContext(retainedAudioTracks).catch((error) =>
        this.log.warn('Could not release audio context', { ...this.logContext, error }),
      );
      if (isWeb()) {
        window.removeEventListener('beforeunload', this.onPageLeave);
        window.removeEventListener('pagehide', this.onPageLeave);
        window.removeEventListener('freeze', this.onPageLeave);
        navigator.mediaDevices?.removeEventListener?.('devicechange', this.handleDeviceChange);
      }
    } finally {
      this.setAndEmitConnectionState(ConnectionState.Disconnected);
      this.emit(RoomEvent.Disconnected, reason);
    }
  }

  private handleParticipantUpdates = (participantInfos: ParticipantInfo[]) => {
    // handle changes to participant state, and send events
    for (const info of participantInfos) {
      if (info.identity === this.localParticipant.identity) {
        this.localParticipant.updateInfo(info);
        continue;
      }

      // LiveKit server doesn't send identity info prior to version 1.5.2 in disconnect updates
      // so we try to map an empty identity to an already known sID manually
      if (info.identity === '') {
        info.identity = this.sidToIdentity.get(info.sid) ?? '';
      }

      let remoteParticipant = this.remoteParticipants.get(info.identity);

      // when it's disconnected, send updates
      if (info.state === ParticipantInfo_State.DISCONNECTED) {
        this.handleParticipantDisconnected(
          info.identity,
          remoteParticipant,
          info.disconnectReason === DisconnectReason.UNKNOWN_REASON
            ? undefined
            : info.disconnectReason,
        );
      } else {
        // create participant if doesn't exist
        this.getOrCreateParticipant(info.identity, info);
      }
    }

    this.extensionResults.forEach((result) => result.onParticipantUpdates?.(participantInfos));
  };

  private handleParticipantDisconnected(
    identity: string,
    participant?: RemoteParticipant,
    disconnectReason?: DisconnectReason,
  ) {
    // remove and send event
    this.remoteParticipants.delete(identity);
    if (!participant) {
      return;
    }

    participant.trackPublications.forEach((publication) => {
      participant.unpublishTrack(publication.trackSid, true);
    });
    this.emit(RoomEvent.ParticipantDisconnected, participant, disconnectReason);
    participant.setDisconnected();
  }

  // updates are sent only when there's a change to speaker ordering
  private handleActiveSpeakersUpdate = (speakers: SpeakerInfo[]) => {
    const activeSpeakers: Participant[] = [];
    const seenSids: any = {};
    speakers.forEach((speaker) => {
      seenSids[speaker.sid] = true;
      if (speaker.sid === this.localParticipant.sid) {
        this.localParticipant.audioLevel = speaker.level;
        this.localParticipant.setIsSpeaking(true);
        activeSpeakers.push(this.localParticipant);
      } else {
        const p = this.getRemoteParticipantBySid(speaker.sid);
        if (p) {
          p.audioLevel = speaker.level;
          p.setIsSpeaking(true);
          activeSpeakers.push(p);
        }
      }
    });

    if (!seenSids[this.localParticipant.sid]) {
      this.localParticipant.audioLevel = 0;
      this.localParticipant.setIsSpeaking(false);
    }
    this.remoteParticipants.forEach((p) => {
      if (!seenSids[p.sid]) {
        p.audioLevel = 0;
        p.setIsSpeaking(false);
      }
    });

    this.activeSpeakers = activeSpeakers;
    this.emitWhenConnected(RoomEvent.ActiveSpeakersChanged, activeSpeakers);
  };

  // process list of changed speakers
  private handleSpeakersChanged = (speakerUpdates: SpeakerInfo[]) => {
    const lastSpeakers = new Map<string, Participant>();
    this.activeSpeakers.forEach((p) => {
      const remoteParticipant = this.remoteParticipants.get(p.identity);
      if (remoteParticipant && remoteParticipant.sid !== p.sid) {
        return;
      }
      lastSpeakers.set(p.sid, p);
    });
    speakerUpdates.forEach((speaker) => {
      let p: Participant | undefined = this.getRemoteParticipantBySid(speaker.sid);
      if (speaker.sid === this.localParticipant.sid) {
        p = this.localParticipant;
      }
      if (!p) {
        return;
      }
      p.audioLevel = speaker.level;
      p.setIsSpeaking(speaker.active);

      if (speaker.active) {
        lastSpeakers.set(speaker.sid, p);
      } else {
        lastSpeakers.delete(speaker.sid);
      }
    });
    const activeSpeakers = Array.from(lastSpeakers.values());
    activeSpeakers.sort((a, b) => b.audioLevel - a.audioLevel);
    this.activeSpeakers = activeSpeakers;
    this.emitWhenConnected(RoomEvent.ActiveSpeakersChanged, activeSpeakers);
  };

  private handleStreamStateUpdate = (streamStateUpdate: StreamStateUpdate) => {
    streamStateUpdate.streamStates.forEach((streamState) => {
      const participant = this.getRemoteParticipantBySid(streamState.participantSid);
      if (!participant) {
        return;
      }
      const pub = participant.getTrackPublicationBySid(streamState.trackSid);
      if (!pub || !pub.track) {
        return;
      }
      const newStreamState = Track.streamStateFromProto(streamState.state);
      const prevStreamState = pub.track.streamState;
      pub.track.setStreamState(newStreamState);
      if (newStreamState !== prevStreamState) {
        participant.emit(ParticipantEvent.TrackStreamStateChanged, pub, pub.track.streamState);
        this.emitWhenConnected(
          RoomEvent.TrackStreamStateChanged,
          pub,
          pub.track.streamState,
          participant,
        );
      }
    });
  };

  private handleSubscriptionPermissionUpdate = (update: SubscriptionPermissionUpdate) => {
    const participant = this.getRemoteParticipantBySid(update.participantSid);
    if (!participant) {
      return;
    }
    const pub = participant.getTrackPublicationBySid(update.trackSid);
    if (!pub) {
      return;
    }

    pub.setAllowed(update.allowed);
  };

  private handleSubscriptionError = (update: SubscriptionResponse) => {
    this.cancelPendingTrackAdded(update.trackSid);

    const participant = Array.from(this.remoteParticipants.values()).find((p) =>
      p.trackPublications.has(update.trackSid),
    );
    if (!participant) {
      return;
    }
    const pub = participant.getTrackPublicationBySid(update.trackSid);
    if (!pub) {
      return;
    }

    pub.setSubscriptionError(update.err);
  };

  private handleDataPacket = (packet: DataPacket, encryptionType: Encryption_Type) => {
    // find the participant
    const participant = this.remoteParticipants.get(packet.participantIdentity);
    if (packet.value.case === 'user') {
      this.handleUserPacket(
        participant,
        packet.value.value,
        packet.kind,
        encryptionType,
        packet.participantIdentity,
      );
    } else if (packet.value.case === 'transcription') {
      this.handleTranscription(participant, packet.value.value);
    } else if (packet.value.case === 'sipDtmf') {
      this.handleSipDtmf(participant, packet.value.value);
    } else if (packet.value.case === 'metrics') {
      this.handleMetrics(packet.value.value, participant);
    } else if (packet.value.case) {
      // every other case belongs to an extension (data streams, rpc, ...)
      this.dataPacketHandlers.get(packet.value.case)?.(packet, encryptionType, participant);
    }
  };

  private handleUserPacket = (
    participant: RemoteParticipant | undefined,
    userPacket: UserPacket,
    kind: DataPacket_Kind,
    encryptionType: Encryption_Type,
    participantIdentity: string,
  ) => {
    this.emit(
      RoomEvent.DataReceived,
      userPacket.payload as NonSharedUint8Array,
      participant,
      kind,
      userPacket.topic,
      encryptionType,
      participantIdentity,
    );

    // also emit on the participant
    participant?.emit(
      ParticipantEvent.DataReceived,
      userPacket.payload as NonSharedUint8Array,
      kind,
      encryptionType,
    );
  };

  private handleSipDtmf = (participant: RemoteParticipant | undefined, dtmf: SipDTMF) => {
    this.emit(RoomEvent.SipDTMFReceived, dtmf, participant);

    // also emit on the participant
    participant?.emit(ParticipantEvent.SipDTMFReceived, dtmf);
  };

  private handleTranscription = (
    _remoteParticipant: RemoteParticipant | undefined,
    transcription: TranscriptionModel,
  ) => {
    // find the participant
    const participant =
      transcription.transcribedParticipantIdentity === this.localParticipant.identity
        ? this.localParticipant
        : this.getParticipantByIdentity(transcription.transcribedParticipantIdentity);
    const publication = participant?.trackPublications.get(transcription.trackId);

    const segments = extractTranscriptionSegments(transcription, this.transcriptionReceivedTimes);

    publication?.emit(TrackEvent.TranscriptionReceived, segments);
    participant?.emit(ParticipantEvent.TranscriptionReceived, segments, publication);
    this.emit(RoomEvent.TranscriptionReceived, segments, participant, publication);
  };

  private handleMetrics = (metrics: MetricsBatch, participant?: Participant) => {
    this.emit(RoomEvent.MetricsReceived, metrics, participant);
  };

  bufferedSegments: Map<string, TranscriptionSegmentModel> = new Map();

  private handleAudioPlaybackStarted = () => {
    if (this.canPlaybackAudio) {
      return;
    }
    this.audioEnabled = true;
    this.emit(RoomEvent.AudioPlaybackStatusChanged, true);
  };

  private handleAudioPlaybackFailed = (e: any) => {
    this.log.warn('could not playback audio', { error: e });
    if (!this.canPlaybackAudio) {
      return;
    }
    this.audioEnabled = false;
    this.emit(RoomEvent.AudioPlaybackStatusChanged, false);
  };

  private handleVideoPlaybackStarted = () => {
    if (this.isVideoPlaybackBlocked) {
      this.isVideoPlaybackBlocked = false;
      this.emit(RoomEvent.VideoPlaybackStatusChanged, true);
    }
  };

  private handleVideoPlaybackFailed = () => {
    if (!this.isVideoPlaybackBlocked) {
      this.isVideoPlaybackBlocked = true;
      this.emit(RoomEvent.VideoPlaybackStatusChanged, false);
    }
  };

  /**
   * attempt to select the default devices if the previously selected devices are no longer available after a device change event
   */
  private async selectDefaultDevices() {
    const previousDevices = DeviceManager.getInstance().previousDevices;
    // check for available devices, but don't request permissions in order to avoid prompts for kinds that haven't been used before
    const availableDevices = await DeviceManager.getInstance().getDevices(undefined, false);
    const browser = getBrowser();
    if (browser?.name === 'Chrome' && browser.os !== 'iOS') {
      for (let availableDevice of availableDevices) {
        const previousDevice = previousDevices.find(
          (info) => info.deviceId === availableDevice.deviceId,
        );
        if (
          previousDevice &&
          previousDevice.label !== '' &&
          previousDevice.kind === availableDevice.kind &&
          previousDevice.label !== availableDevice.label
        ) {
          // label has changed on device the same deviceId, indicating that the default device has changed on the OS level
          if (this.getActiveDevice(availableDevice.kind) === 'default') {
            // emit an active device change event only if the selected output device is actually on `default`
            this.emit(
              RoomEvent.ActiveDeviceChanged,
              availableDevice.kind,
              availableDevice.deviceId,
            );
          }
        }
      }
    }

    const kinds: MediaDeviceKind[] = ['audiooutput', 'audioinput', 'videoinput'];
    for (let kind of kinds) {
      const targetSource = kindToSource(kind);
      const targetPublication = this.localParticipant.getTrackPublication(targetSource);
      if (targetPublication && targetPublication.track?.isUserProvided) {
        // if the track is user provided, we don't want to switch devices on behalf of the user
        continue;
      }
      const devicesOfKind = availableDevices.filter((d) => d.kind === kind);
      const activeDevice = this.getActiveDevice(kind);

      if (activeDevice === previousDevices.filter((info) => info.kind === kind)[0]?.deviceId) {
        // in  Safari the first device is always the default, so we assume a user on the default device would like to switch to the default once it changes
        // FF doesn't emit an event when the default device changes, so we perform the same best effort and switch to the new device once connected and if it's the first in the array
        if (devicesOfKind.length > 0 && devicesOfKind[0]?.deviceId !== activeDevice) {
          await this.switchActiveDevice(kind, devicesOfKind[0].deviceId);
          continue;
        }
      }

      if ((kind === 'audioinput' && !isSafariBased()) || kind === 'videoinput') {
        // airpods on Safari need special handling for audioinput as the track doesn't end as soon as you take them out
        continue;
      }
      // switch to first available device if previously active device is not available any more
      if (
        devicesOfKind.length > 0 &&
        !devicesOfKind.find((deviceInfo) => deviceInfo.deviceId === this.getActiveDevice(kind)) &&
        // avoid switching audio output on safari without explicit user action as it leads to slowed down audio playback
        (kind !== 'audiooutput' || !isSafariBased())
      ) {
        await this.switchActiveDevice(kind, devicesOfKind[0].deviceId);
      }
    }
  }

  private handleDeviceChange = async () => {
    if (getBrowser()?.os !== 'iOS') {
      // default devices are non deterministic on iOS, so we don't attempt to select them here
      await this.selectDefaultDevices();
    }
    this.emit(RoomEvent.MediaDevicesChanged);
  };

  private handleRoomUpdate = (room: RoomModel) => {
    const oldRoom = this.roomInfo;
    this.roomInfo = room;
    if (oldRoom && oldRoom.metadata !== room.metadata) {
      this.emitWhenConnected(RoomEvent.RoomMetadataChanged, room.metadata);
    }
    if (oldRoom?.activeRecording !== room.activeRecording) {
      this.emitWhenConnected(RoomEvent.RecordingStatusChanged, room.activeRecording);
    }
  };

  private handleConnectionQualityUpdate = (update: ConnectionQualityUpdate) => {
    update.updates.forEach((info) => {
      if (info.participantSid === this.localParticipant.sid) {
        this.localParticipant.setConnectionQuality(info.quality);
        return;
      }
      const participant = this.getRemoteParticipantBySid(info.participantSid);
      if (participant) {
        participant.setConnectionQuality(info.quality);
      }
    });
  };

  /**
   * @param forConnect whether this acquisition belongs to a connect, which is the only caller
   * allowed to put a released room back on an audio context.
   */
  private async acquireAudioContext(forConnect = false) {
    const unlock = await this.audioContextMutex.lock();
    try {
      if (this.audioContextReleased && !forConnect) {
        // a disconnect set the flag and took the lock while this call was queued behind it.
        // Creating a context now would leave one open on a room nothing tears down again
        return;
      }
      this.audioContextReleased = false;
      const providedAudioContext =
        typeof this.options.webAudioMix !== 'boolean'
          ? this.options.webAudioMix.audioContext
          : undefined;
      if (providedAudioContext) {
        // override audio context with custom audio context if supplied by user
        await this.setRoomAudioContext(providedAudioContext, false);
      } else if (!this.audioContext || this.audioContext.state === 'closed') {
        // by using an AudioContext, it reduces lag on audio elements
        // https://stackoverflow.com/questions/9811429/html5-audio-tag-on-safari-has-a-delay/54119854#54119854
        await this.setRoomAudioContext(getNewAudioContext() ?? undefined, true);
      }

      if (this.audioContext && this.audioContext.state === 'suspended') {
        // for iOS a newly created AudioContext is always in `suspended` state.
        // we try our best to resume the context here, if that doesn't work, we just continue with regular processing
        try {
          await Promise.race([this.audioContext.resume(), sleep(200)]);
        } catch (e: any) {
          this.log.warn('Could not resume audio context', { error: e });
        }
      }

      const newContextIsRunning = this.audioContext?.state === 'running';
      if (newContextIsRunning !== this.canPlaybackAudio) {
        this.audioEnabled = newContextIsRunning;
        this.emit(RoomEvent.AudioPlaybackStatusChanged, newContextIsRunning);
      }
    } finally {
      unlock();
    }
  }

  /**
   * Points the room and its participants at `audioContext`, rebuilding the web audio graph of
   * every audio track in it. Closes the previous context if the SDK `owned` it.
   */
  private async setRoomAudioContext(audioContext: AudioContext | undefined, owned: boolean) {
    const ownsAudioContext = !!audioContext && owned;
    if (this.audioContext === audioContext) {
      this.ownsAudioContext = ownsAudioContext;
      return;
    }
    const contextToClose = this.ownsAudioContext ? this.audioContext : undefined;
    this.audioContext = audioContext;
    this.ownsAudioContext = ownsAudioContext;

    try {
      // every audio track rebuilds its nodes in the new context, which has to happen before the
      // previous one is closed so that processors can move off it while it is still alive
      if (this.options.webAudioMix) {
        await Promise.all(
          Array.from(this.remoteParticipants.values()).map((participant) =>
            participant.setAudioContext(audioContext),
          ),
        );
      }
      await this.localParticipant.setAudioContext(audioContext);
    } catch (error) {
      // the context is being abandoned either way, so a track that failed to move off it must
      // not stop us closing it — that would leak the context this whole path exists to release
      this.log.warn('Could not move audio tracks to the new audio context', {
        ...this.logContext,
        error,
      });
    } finally {
      if (contextToClose && contextToClose.state !== 'closed') {
        try {
          await contextToClose.close();
        } catch (error) {
          this.log.warn('Could not close audio context', { ...this.logContext, error });
        }
      }
    }
  }

  /**
   * Detaches the web audio graph the SDK built from the current audio context and closes that
   * context if the SDK created it. A context provided through `webAudioMix` is left untouched.
   */
  private async releaseAudioContext(retainedAudioTracks: LocalAudioTrack[] = []) {
    // both reads happen before the first await, so they describe the room as it was when the
    // disconnect started rather than after a reconnect has had a chance to run
    this.audioContextReleased = true;
    const contextToRelease = this.audioContext;
    const unlock = await this.audioContextMutex.lock();
    try {
      if (!this.audioContextReleased || this.audioContext !== contextToRelease) {
        // a reconnect acquired a new context while we were waiting, closing it would leave the
        // reconnected room without one
        return;
      }
      if (!this.ownsAudioContext) {
        // a provided context stays open, so tracks that outlive the room stay functional on it.
        // The tracks this room detached have released their nodes during track teardown already.
        // read under the lock: an acquire queued behind an in-flight release flips this flag
        return;
      }
      try {
        // tracks that outlive the room aren't reachable through the local participant anymore,
        // but still hold web audio nodes in the context we're about to close
        await Promise.all(retainedAudioTracks.map((track) => track.setAudioContext(undefined)));
      } catch (error) {
        this.log.warn('Could not detach retained audio tracks from the audio context', {
          ...this.logContext,
          error,
        });
      }
      // the participant maps have already been cleared by `handleDisconnect`, so this reaches no
      // tracks of its own — `retainedAudioTracks` above is what detaches them
      await this.setRoomAudioContext(undefined, false);
    } finally {
      unlock();
    }
  }

  private createParticipant(identity: string, info?: ParticipantInfo): RemoteParticipant {
    let participant: RemoteParticipant;
    if (info) {
      participant = RemoteParticipant.fromParticipantInfo(this.engine.client, info, {
        loggerContextCb: () => this.logContext,
        loggerName: this.options.loggerName,
      });
      this.extensionResults.forEach((result) => result.onParticipantCreated?.(participant, info));
    } else {
      participant = new RemoteParticipant(
        this.engine.client,
        '',
        identity,
        undefined,
        undefined,
        undefined,
        {
          loggerContextCb: () => this.logContext,
          loggerName: this.options.loggerName,
        },
      );
    }
    if (this.options.webAudioMix) {
      participant
        .setAudioContext(this.audioContext)
        .catch((error) =>
          this.log.warn('Could not set audio context', { ...this.logContext, error }),
        );
    }
    if (this.options.audioOutput?.deviceId) {
      participant
        .setAudioOutput(this.options.audioOutput)
        .catch((e) => this.log.warn(`Could not set audio output: ${e.message}`));
    }
    return participant;
  }

  private getOrCreateParticipant(identity: string, info: ParticipantInfo): RemoteParticipant {
    if (this.remoteParticipants.has(identity)) {
      const existingParticipant = this.remoteParticipants.get(identity)!;
      if (info) {
        const wasUpdated = existingParticipant.updateInfo(info);
        if (wasUpdated) {
          this.sidToIdentity.set(info.sid, info.identity);
        }
      }
      return existingParticipant;
    }
    const participant = this.createParticipant(identity, info);
    this.remoteParticipants.set(identity, participant);

    this.sidToIdentity.set(info.sid, info.identity);
    // if we have valid info and the participant wasn't in the map before, we can assume the participant is new
    // firing here to make sure that `ParticipantConnected` fires before the initial track events
    this.emitWhenConnected(RoomEvent.ParticipantConnected, participant);

    // also forward events
    // trackPublished is only fired for tracks added after both local participant
    // and remote participant joined the room
    participant
      .on(ParticipantEvent.TrackPublished, (trackPublication: RemoteTrackPublication) => {
        this.emitWhenConnected(RoomEvent.TrackPublished, trackPublication, participant);
      })
      .on(
        ParticipantEvent.TrackSubscribed,
        (track: RemoteTrack, publication: RemoteTrackPublication) => {
          // monitor playback status
          if (track.kind === Track.Kind.Audio) {
            track.on(TrackEvent.AudioPlaybackStarted, this.handleAudioPlaybackStarted);
            track.on(TrackEvent.AudioPlaybackFailed, this.handleAudioPlaybackFailed);
          } else if (track.kind === Track.Kind.Video) {
            track.on(TrackEvent.VideoPlaybackFailed, this.handleVideoPlaybackFailed);
            track.on(TrackEvent.VideoPlaybackStarted, this.handleVideoPlaybackStarted);
          }
          this.emitWhenConnected(RoomEvent.TrackSubscribed, track, publication, participant);
        },
      )
      .on(ParticipantEvent.TrackUnpublished, (publication: RemoteTrackPublication) => {
        this.cancelPendingTrackAdded(publication.trackSid);
        this.emit(RoomEvent.TrackUnpublished, publication, participant);
      })
      .on(
        ParticipantEvent.TrackUnsubscribed,
        (track: RemoteTrack, publication: RemoteTrackPublication) => {
          this.emit(RoomEvent.TrackUnsubscribed, track, publication, participant);
        },
      )
      .on(ParticipantEvent.TrackMuted, (pub: TrackPublication) => {
        this.emitWhenConnected(RoomEvent.TrackMuted, pub, participant);
      })
      .on(ParticipantEvent.TrackUnmuted, (pub: TrackPublication) => {
        this.emitWhenConnected(RoomEvent.TrackUnmuted, pub, participant);
      })
      .on(ParticipantEvent.ParticipantMetadataChanged, (metadata: string | undefined) => {
        this.emitWhenConnected(RoomEvent.ParticipantMetadataChanged, metadata, participant);
      })
      .on(ParticipantEvent.ParticipantNameChanged, (name) => {
        this.emitWhenConnected(RoomEvent.ParticipantNameChanged, name, participant);
      })
      .on(ParticipantEvent.AttributesChanged, (changedAttributes: Record<string, string>) => {
        this.emitWhenConnected(
          RoomEvent.ParticipantAttributesChanged,
          changedAttributes,
          participant,
        );
      })
      .on(ParticipantEvent.ConnectionQualityChanged, (quality: ConnectionQuality) => {
        this.emitWhenConnected(RoomEvent.ConnectionQualityChanged, quality, participant);
      })
      .on(
        ParticipantEvent.ParticipantPermissionsChanged,
        (prevPermissions?: ParticipantPermission) => {
          this.emitWhenConnected(
            RoomEvent.ParticipantPermissionsChanged,
            prevPermissions,
            participant,
          );
        },
      )
      .on(ParticipantEvent.TrackSubscriptionStatusChanged, (pub, status) => {
        this.emitWhenConnected(RoomEvent.TrackSubscriptionStatusChanged, pub, status, participant);
      })
      .on(ParticipantEvent.TrackSubscriptionFailed, (trackSid, error) => {
        this.emit(RoomEvent.TrackSubscriptionFailed, trackSid, participant, error);
      })
      .on(ParticipantEvent.TrackSubscriptionPermissionChanged, (pub, status) => {
        this.emitWhenConnected(
          RoomEvent.TrackSubscriptionPermissionChanged,
          pub,
          status,
          participant,
        );
      })
      .on(ParticipantEvent.Active, () => {
        this.emitWhenConnected(RoomEvent.ParticipantActive, participant);
        if (participant.kind === ParticipantKind.AGENT) {
          this.localParticipant.setActiveAgent(participant);
        }
      });

    // update info at the end after callbacks have been set up
    if (info) {
      participant.updateInfo(info);
    }
    return participant;
  }

  private sendSyncState() {
    const remoteTracks = Array.from(this.remoteParticipants.values()).reduce((acc, participant) => {
      acc.push(...(participant.getTrackPublications() as RemoteTrackPublication[])); // FIXME would be nice to have this return RemoteTrackPublications directly instead of the type cast
      return acc;
    }, [] as RemoteTrackPublication[]);
    const localTracks = this.localParticipant.getTrackPublications() as LocalTrackPublication[]; // FIXME would be nice to have this return LocalTrackPublications directly instead of the type cast
    const publishDataTracks = ([] as PublishDataTrackResponse[]).concat(
      ...this.extensionResults.map((result) => result.syncState?.() ?? []),
    );
    this.engine.sendSyncState(remoteTracks, localTracks, publishDataTracks);
  }

  /**
   * After resuming, we'll need to notify the server of the current
   * subscription settings.
   */
  private updateSubscriptions() {
    for (const p of this.remoteParticipants.values()) {
      for (const pub of p.videoTrackPublications.values()) {
        if (pub.isSubscribed && isRemotePub(pub)) {
          pub.emitTrackUpdate();
        }
      }
    }
  }

  private getRemoteParticipantBySid(sid: string): RemoteParticipant | undefined {
    const identity = this.sidToIdentity.get(sid);
    if (identity) {
      return this.remoteParticipants.get(identity);
    }
  }

  /** The client capabilities this SDK advertises to other participants in its `ClientInfo`. */
  private getClientInfoCapabilities(): Array<ClientInfo_Capability> {
    const capabilities: Array<ClientInfo_Capability> = [];
    if (isFrameMetadataSupported(this.slots.frameMetadataOptions) || !!this.slots.e2eeManager) {
      capabilities.push(ClientInfo_Capability.CAP_PACKET_TRAILER);
    }
    // Advertise deflate-raw decompression support so peers know they can send us compressed data
    // streams (gated separately from clientProtocol — see the data streams v2 spec).
    if (isDeflateRawCompressionSupported()) {
      capabilities.push(ClientInfo_Capability.CAP_COMPRESSION_DEFLATE_RAW);
    }
    return capabilities;
  }

  private setStatsLogging(enabled: boolean) {
    if (enabled) {
      if (!this.statsLogInterval) {
        this.statsLogInterval = CriticalTimers.setInterval(() => {
          // logWebRTCStats handles its own errors, nothing to await here
          this.logWebRTCStats();
        }, STATS_LOG_FREQUENCY_MS);
      }
    } else if (this.statsLogInterval) {
      CriticalTimers.clearInterval(this.statsLogInterval);
      this.statsLogInterval = undefined;
    }
  }

  /**
   * Dumps stats of both peer connections.
   */
  private logWebRTCStats = async () => {
    const pcManager = this.engine?.pcManager;
    if (!pcManager) {
      return;
    }
    try {
      const [publisher, subscriber] = await Promise.all([
        pcManager.publisher.getStats(),
        pcManager.subscriber?.getStats(),
      ]);
      const publisherStats = publisher && summarizeStatsReport(publisher);
      const subscriberStats = subscriber && summarizeStatsReport(subscriber);
      this.statsLog.info(`webrtc stats`, {
        publisher: publisherStats?.connection,
        subscriber: subscriberStats?.connection,
        inbound: [...(publisherStats?.inbound ?? []), ...(subscriberStats?.inbound ?? [])],
        outbound: publisherStats?.outbound,
      });
    } catch (error) {
      this.statsLog.debug('could not collect webrtc stats', { error });
    }
  };

  private registerConnectionReconcile() {
    this.clearConnectionReconcile();
    let consecutiveFailures = 0;
    this.connectionReconcileInterval = CriticalTimers.setInterval(() => {
      if (
        // ensure we didn't tear it down
        !this.engine ||
        // engine detected close, but Room missed it
        this.engine.isClosed ||
        // transports failed without notifying engine
        !this.engine.verifyTransport()
      ) {
        consecutiveFailures++;
        this.log.warn('detected connection state mismatch', {
          numFailures: consecutiveFailures,
          engine: this.engine
            ? {
                closed: this.engine.isClosed,
                transportsConnectedOrConnecting: this.engine.verifyTransport(),
              }
            : undefined,
        });
        if (consecutiveFailures >= 3) {
          this.clearConnectionReconcile();
          if (this.engine && !this.engine.isClosed) {
            // The transport silently died while we still looked connected. Try a full reconnect
            // (keeps the room alive; the engine falls back to Disconnected if it ultimately fails).
            this.log.warn('detected connection state mismatch, attempting full reconnect');
            this.engine.reconnect();
          } else {
            // No usable engine to reconnect with; tear down.
            this.recreateEngine();
            this.handleDisconnect(
              this.options.stopLocalTrackOnUnpublish,
              DisconnectReason.STATE_MISMATCH,
            );
          }
        }
      } else {
        consecutiveFailures = 0;
      }
    }, CONNECTION_RECONCILE_FREQUENCY_MS);
  }

  private clearConnectionReconcile() {
    if (this.connectionReconcileInterval) {
      CriticalTimers.clearInterval(this.connectionReconcileInterval);
    }
  }

  private setAndEmitConnectionState(state: ConnectionState): boolean {
    if (state === this.state) {
      // unchanged
      return false;
    }
    this.log.info(`connection state changed: ${this.state} -> ${state}`);
    this.state = state;
    this.setStatsLogging(state === ConnectionState.Connected);

    this.emit(RoomEvent.ConnectionStateChanged, this.state);

    return true;
  }

  private emitBufferedEvents() {
    this.bufferedEvents.forEach(([ev, args]) => {
      this.emit(ev, ...args);
    });
    this.bufferedEvents = [];
  }

  private emitWhenConnected<E extends keyof RoomEventCallbacks>(
    event: E,
    ...args: Parameters<RoomEventCallbacks[E]>
  ): boolean {
    if (
      this.state === ConnectionState.Reconnecting ||
      this.isResuming ||
      !this.engine ||
      this.engine.pendingReconnect
    ) {
      // in case the room is reconnecting, buffer the events by firing them later after emitting RoomEvent.Reconnected
      this.bufferedEvents.push([event, args]);
    } else if (this.state === ConnectionState.Connected) {
      return this.emit(event, ...args);
    }
    return false;
  }

  private onLocalParticipantMetadataChanged = (metadata: string | undefined) => {
    this.emit(RoomEvent.ParticipantMetadataChanged, metadata, this.localParticipant);
  };

  private onLocalParticipantNameChanged = (name: string) => {
    this.emit(RoomEvent.ParticipantNameChanged, name, this.localParticipant);
  };

  private onLocalAttributesChanged = (changedAttributes: Record<string, string>) => {
    this.emit(RoomEvent.ParticipantAttributesChanged, changedAttributes, this.localParticipant);
  };

  private onLocalTrackMuted = (pub: TrackPublication) => {
    this.emit(RoomEvent.TrackMuted, pub, this.localParticipant);
  };

  private onLocalTrackUnmuted = (pub: TrackPublication) => {
    this.emit(RoomEvent.TrackUnmuted, pub, this.localParticipant);
  };

  private onTrackProcessorUpdate = (processor?: TrackProcessor<Track.Kind, any>) => {
    processor?.onPublish?.(this);
  };

  private onLocalTrackPublished = async (pub: LocalTrackPublication) => {
    pub.track?.on(TrackEvent.TrackProcessorUpdate, this.onTrackProcessorUpdate);
    pub.track?.on(TrackEvent.Restarted, this.onLocalTrackRestarted);
    pub.track?.getProcessor()?.onPublish?.(this);

    this.emit(RoomEvent.LocalTrackPublished, pub, this.localParticipant);

    if (isLocalAudioTrack(pub.track)) {
      const trackIsSilent = await pub.track.checkForSilence();
      if (trackIsSilent) {
        this.emit(RoomEvent.LocalAudioSilenceDetected, pub);
      }
    }
    const deviceId = await pub.track?.getDeviceId(false);
    const deviceKind = sourceToKind(pub.source);
    if (
      deviceKind &&
      deviceId &&
      deviceId !== this.localParticipant.activeDeviceMap.get(deviceKind)
    ) {
      this.localParticipant.activeDeviceMap.set(deviceKind, deviceId);
      this.emit(RoomEvent.ActiveDeviceChanged, deviceKind, deviceId);
    }
  };

  private onLocalTrackUnpublished = (pub: LocalTrackPublication) => {
    pub.track?.off(TrackEvent.TrackProcessorUpdate, this.onTrackProcessorUpdate);
    pub.track?.off(TrackEvent.Restarted, this.onLocalTrackRestarted);
    this.emit(RoomEvent.LocalTrackUnpublished, pub, this.localParticipant);
  };

  private onLocalTrackRestarted = async (track: LocalTrack) => {
    const deviceId = await track.getDeviceId(false);
    const deviceKind = sourceToKind(track.source);
    if (
      deviceKind &&
      deviceId &&
      deviceId !== this.localParticipant.activeDeviceMap.get(deviceKind)
    ) {
      this.log.debug(`local track restarted, setting ${deviceKind} ${deviceId} active`);
      this.localParticipant.activeDeviceMap.set(deviceKind, deviceId);
      this.emit(RoomEvent.ActiveDeviceChanged, deviceKind, deviceId);
    }
  };

  private onLocalConnectionQualityChanged = (quality: ConnectionQuality) => {
    this.emit(RoomEvent.ConnectionQualityChanged, quality, this.localParticipant);
  };

  private onMediaDevicesError = (e: Error, kind?: MediaDeviceKind) => {
    this.emit(RoomEvent.MediaDevicesError, e, kind);
  };

  private onLocalParticipantPermissionsChanged = (prevPermissions?: ParticipantPermission) => {
    this.emit(RoomEvent.ParticipantPermissionsChanged, prevPermissions, this.localParticipant);
  };

  /** Puts the room into the connected state without a server (`ExtensionContext.simulateConnected`). */
  private simulateConnected(roomInfo: RoomModel, localParticipantInfo: ParticipantInfo) {
    this.handleDisconnect();
    this.roomInfo = roomInfo;
    this.localParticipant.updateInfo(localParticipantInfo);
    this.setupLocalParticipantEvents();
    this.emit(RoomEvent.SignalConnected);
    this.emit(RoomEvent.Connected);
    this.setAndEmitConnectionState(ConnectionState.Connected);
  }

  // /** @internal */
  emit<E extends keyof RoomEventCallbacks>(
    event: E,
    ...args: Parameters<RoomEventCallbacks[E]>
  ): boolean {
    // active speaker updates are too spammy
    if (event !== RoomEvent.ActiveSpeakersChanged && event !== RoomEvent.TranscriptionReceived) {
      // only extract logContext from arguments in order to avoid logging the whole object tree
      const minimizedArgs = mapArgs(args).filter((arg: unknown) => arg !== undefined);
      if (event === RoomEvent.TrackSubscribed || event === RoomEvent.TrackUnsubscribed) {
        this.log.trace(`subscribe trace: ${event}`, { event, args: minimizedArgs });
      }
      this.log.debug(`room event ${event}`, { event, args: minimizedArgs });
    }
    return super.emit(event, ...args);
  }
}

function mapArgs(args: unknown[]): any {
  return args.map((arg: unknown) => {
    if (!arg) {
      return;
    }
    if (Array.isArray(arg)) {
      return mapArgs(arg);
    }
    if (typeof arg === 'object') {
      return 'logContext' in arg ? arg.logContext : undefined;
    }
    return arg;
  });
}

/** Copies an extension's API onto `target`. Refuses to redefine an existing member. */
/**
 * Copies an extension's API onto `target`. A name that core (`base`) or an earlier extension
 * already defines is a collision. A name a subclass of `base` defines is an override: the
 * subclass method stays and the extension's is not installed, so `Room` subclasses that
 * override a moved method keep working (there is no `super` to call, the override replaces it).
 */
function defineExtensionApi(
  target: object,
  base: object,
  api: object | undefined,
  ext: RoomExtension<any, any>,
) {
  if (!api) {
    return;
  }
  const descriptors = Object.getOwnPropertyDescriptors(api);
  for (const name of Object.keys(descriptors)) {
    if (Object.getOwnPropertyDescriptor(target, name) || name in base) {
      // @throws-transformer ignore - programmer error
      throw new Error(`extension '${String(ext.key)}' redefines '${name}'`);
    }
    if (name in target) {
      delete descriptors[name];
    }
  }
  // defineProperties (not Object.assign) keeps getters intact
  Object.defineProperties(target, descriptors);
}

export default CoreRoom;

export type RoomEventCallbacks = {
  connected: () => void;
  reconnecting: () => void;
  signalReconnecting: () => void;
  reconnected: () => void;
  disconnected: (reason?: DisconnectReason) => void;
  connectionStateChanged: (state: ConnectionState) => void;
  moved: (name: string) => void;
  mediaDevicesChanged: () => void;
  participantConnected: (participant: RemoteParticipant) => void;
  participantDisconnected: (
    participant: RemoteParticipant,
    disconnectReason?: DisconnectReason,
  ) => void;
  trackPublished: (publication: RemoteTrackPublication, participant: RemoteParticipant) => void;
  trackSubscribed: (
    track: RemoteTrack,
    publication: RemoteTrackPublication,
    participant: RemoteParticipant,
  ) => void;
  trackSubscriptionFailed: (
    trackSid: string,
    participant: RemoteParticipant,
    reason?: SubscriptionError,
  ) => void;
  trackUnpublished: (publication: RemoteTrackPublication, participant: RemoteParticipant) => void;
  trackUnsubscribed: (
    track: RemoteTrack,
    publication: RemoteTrackPublication,
    participant: RemoteParticipant,
  ) => void;
  trackMuted: (publication: TrackPublication, participant: Participant) => void;
  trackUnmuted: (publication: TrackPublication, participant: Participant) => void;
  localTrackPublished: (publication: LocalTrackPublication, participant: LocalParticipant) => void;
  localTrackUnpublished: (
    publication: LocalTrackPublication,
    participant: LocalParticipant,
  ) => void;
  localAudioSilenceDetected: (publication: LocalTrackPublication) => void;
  participantMetadataChanged: (
    metadata: string | undefined,
    participant: RemoteParticipant | LocalParticipant,
  ) => void;
  participantNameChanged: (name: string, participant: RemoteParticipant | LocalParticipant) => void;
  participantPermissionsChanged: (
    prevPermissions: ParticipantPermission | undefined,
    participant: RemoteParticipant | LocalParticipant,
  ) => void;
  participantAttributesChanged: (
    changedAttributes: Record<string, string>,
    participant: RemoteParticipant | LocalParticipant,
  ) => void;
  activeSpeakersChanged: (speakers: Array<Participant>) => void;
  roomMetadataChanged: (metadata: string) => void;
  dataReceived: (
    payload: NonSharedUint8Array,
    participant?: RemoteParticipant,
    kind?: DataPacket_Kind,
    topic?: string,
    encryptionType?: Encryption_Type,
    participantIdentity?: string,
  ) => void;
  sipDTMFReceived: (dtmf: SipDTMF, participant?: RemoteParticipant) => void;
  transcriptionReceived: (
    transcription: TranscriptionSegment[],
    participant?: Participant,
    publication?: TrackPublication,
  ) => void;
  connectionQualityChanged: (quality: ConnectionQuality, participant: Participant) => void;
  mediaDevicesError: (error: Error, kind?: MediaDeviceKind) => void;
  trackStreamStateChanged: (
    publication: RemoteTrackPublication,
    streamState: Track.StreamState,
    participant: RemoteParticipant,
  ) => void;
  trackSubscriptionPermissionChanged: (
    publication: RemoteTrackPublication,
    status: TrackPublication.PermissionStatus,
    participant: RemoteParticipant,
  ) => void;
  trackSubscriptionStatusChanged: (
    publication: RemoteTrackPublication,
    status: TrackPublication.SubscriptionStatus,
    participant: RemoteParticipant,
  ) => void;
  audioPlaybackChanged: (playing: boolean) => void;
  videoPlaybackChanged: (playing: boolean) => void;
  signalConnected: () => void;
  recordingStatusChanged: (recording: boolean) => void;
  participantEncryptionStatusChanged: (encrypted: boolean, participant?: Participant) => void;
  encryptionError: (error: Error, participant?: Participant) => void;
  dcBufferStatusChanged: (isLow: boolean, kind: DataChannelKind) => void;
  activeDeviceChanged: (kind: MediaDeviceKind, deviceId: string) => void;
  chatMessage: (message: ChatMessage, participant?: RemoteParticipant | LocalParticipant) => void;
  localTrackSubscribed: (publication: LocalTrackPublication, participant: LocalParticipant) => void;
  metricsReceived: (metrics: MetricsBatch, participant?: Participant) => void;
  participantActive: (participant: Participant) => void;
  dataTrackPublished: (track: RemoteDataTrack) => void;
  dataTrackUnpublished: (sid: DataTrackSid) => void;
  localDataTrackPublished: (track: LocalDataTrack) => void;
  localDataTrackUnpublished: (sid: DataTrackSid) => void;
};
